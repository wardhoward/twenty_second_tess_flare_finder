import copy
import numpy as np
import matplotlib.pyplot as plt
import scipy.signal
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit

def davenport_flare_model(epochs, width, ampl, peak_time):

    if width==0.0 and ampl==0.0 and peak_time==0.0:
        return np.zeros(len(epochs))
    elif ampl<0.000001:
        ampl=100000.0
    else:
        pass
    
    # See Davenport et al 2014, ApJ 797, 2
    t = copy.deepcopy(epochs)
    t/=width
    #assume a gaussian-distribution 1-5mins for risetime, 20-30mins decay
    try:
        flare_y = 0.689*np.exp(-1.6*(t-peak_time),dtype=np.float64) + 0.303*np.exp(-0.2783*(t-peak_time),dtype=np.float64)
    except (RuntimeWarning):
        #print np.exp(-1.6*(t-peak_time),dtype=np.float64)
        #print np.exp(-0.2783*(t-peak_time),dtype=np.float64)
        exit()
    flare_y[(t-peak_time)<0] = 1.0 + (1.941)*(t-peak_time)[(t-peak_time)<0] - 0.175*((t-peak_time)[(t-peak_time)<0]**2) - 2.246*((t-peak_time)[(t-peak_time)<0]**3) - 1.125*((t-peak_time)[(t-peak_time)<0]**4)

    flare_y[flare_y<0.000001]= 0.000001 #set all flare points that would otherwise be negative to val near zero
    flare_y = flare_y*ampl #adjust flare peak amplitude
    #rise; FWHMs not minutes
    return flare_y

def get_Q0_luminosity(d, inband_mag, bandpass):

    TESS_0 = 4.03*(10.0**(-6.0)) #Sullivan 2015, 4.03 x 10^-6 erg /s cm2
    TESS_0 = TESS_0 * (10.0**(-7.0)) #J/erg, now in J/(s cm^2) or W/cm^2
    TESS_0 = TESS_0 * (10.0**4.0) #cm^2 / m^2, now in W/m^2

    #print TESS_0 #W/m^2
    #print np.log10(TESS_0)


    meters_per_pc = 3.086*(10.0**(16.0))
    #d = 1.3018 #Proxima dist, parsec
    d*=meters_per_pc #parsecs to meters
    d*=100.0 #meters to cm

    mu=0.15 # eff g' in micrometers from Gemini
    g0_flux = 5.41*(10.0**-8.0) # in W/m^2/mu
    watt_to_erg_per_sec = 10.0**7.0 # J/sec to ergs/sec
    meter2_to_cm2 = 10.0**(-4.0) # m^2 / cm^2

    if bandpass == "g-mag":
        g0_flux_erg = g0_flux*mu*watt_to_erg_per_sec*meter2_to_cm2
    elif bandpass == "T-mag":
        g0_flux_erg = TESS_0*watt_to_erg_per_sec*meter2_to_cm2
    else:
        print ("No such bandpass",bandpass)
        print ("Exiting now.")
        exit()

    #from apparent mag to stellar flux:
    F_star = g0_flux_erg * 10.0**((inband_mag)/(-2.5))

    Q_0 = 4.0*np.pi*(d**2.0)*F_star #quiesc. flux in g' in erg/s

    return Q_0

def get_Q_0_errors(g_mags_val, e_mags_val, TESS_mags_val, e_TESS_mags_val, dist_pc, e_dist_pc):

    n_trials = 1000

    dist1_sampler = np.random.normal(dist_pc, e_dist_pc, n_trials)
    dist2_sampler = np.random.normal(dist_pc, e_dist_pc, n_trials)
    gmag_sampler = np.random.normal(g_mags_val, e_mags_val, n_trials)
    Tmag_sampler = np.random.normal(TESS_mags_val, e_TESS_mags_val, n_trials)

    evry_quiesc=[]
    tess_quiesc=[]
    for n in np.arange(n_trials):
        evr_Q_0 = get_Q0_luminosity(dist1_sampler[n], gmag_sampler[n], "g-mag") #g-mag
        tess_Q_0 = get_Q0_luminosity(dist2_sampler[n], Tmag_sampler[n], "T-mag")

        evry_quiesc.append(evr_Q_0)
        tess_quiesc.append(tess_Q_0)
    evry_quiesc= np.array(evry_quiesc)
    tess_quiesc= np.array(tess_quiesc)

    evry_std_Q_0 = np.std(evry_quiesc)
    tess_std_Q_0 = np.std(tess_quiesc)

    evr_Q_0 = get_Q0_luminosity(dist_pc, g_mags_val, "g-mag") #g-mag

    tess_Q_0 = get_Q0_luminosity(dist_pc, TESS_mags_val, "T-mag") #T-mag

    """
    plt.axvline(evr_Q_0,color="black")
    plt.axvline(evr_Q_0 + evry_std_Q_0,color="grey")
    plt.axvline(evr_Q_0 - evry_std_Q_0,color="grey")
    plt.hist(evry_quiesc)
    plt.show()

    plt.axvline(tess_Q_0,color="black")
    plt.axvline(tess_Q_0 + tess_std_Q_0,color="grey")
    plt.axvline(tess_Q_0 - tess_std_Q_0,color="grey")
    plt.hist(tess_quiesc,color="firebrick")
    plt.show()
    #exit()
    """
    
    return (evr_Q_0, evry_std_Q_0, tess_Q_0, tess_std_Q_0)


####

TIC_ID = 229807000 #Please ignore, unique designator i=4 from longer code

#g_mags_val, e_mags_val, TESS_mags_val, e_TESS_mags_val, dist_pc, e_dist_pc = (13.672, 0.016, 10.7988, 0.00746892, 45.9868, 0.05)

# get errors in quiescent luminosities:
#evr_Q_0, err_evr_Q_0, tess_Q_0, err_tess_Q_0 = get_Q_0_errors(g_mags_val, e_mags_val, TESS_mags_val, e_TESS_mags_val, dist_pc, e_dist_pc)

x_tess = np.array([0.04166609, 0.04305496, 0.04444383, 0.0458327, 0.04722157, 0.04861044, 0.04999931, 0.05138818, 0.05277705, 0.05416592, 0.05555479, 0.05694366, 0.05833253, 0.0597214,  0.06111027, 0.06249914, 0.06388801, 0.06527688, 0.06666575, 0.06805462, 0.06944349, 0.07222122, 0.07361009, 0.07499896, 0.07638783]) #time in days

y_tess = np.array([-6.64396331e-03, -5.39495222e-04, -2.71480565e-03, -5.27933822e-04, -5.07532817e-03, -2.41727865e-03, -2.17085249e-03, -9.69692440e-05, -1.11860046e-03, -1.24928305e-03, 3.57536289e-01, 4.95350780e-01, 3.87706149e-01, 2.90381472e-01, 2.21308310e-01, 1.72042265e-01, 1.44163131e-01, 1.24434168e-01, 1.07516640e-01, 8.84698381e-02, 7.24482239e-02, 4.51191690e-02, 3.88339081e-02, 2.85836528e-02, 2.32568622e-02]) #y values of flare in fractional flux


#first try to fit, a good but imperfect guess
popt_tess = [0.005, 0.6, 11.5] #[width-in-FWHMs, peak flare amplitude, unitless time-of-peak height]
sampled_flare = davenport_flare_model(x_tess, *popt_tess)

plt.title("First attempt, a good guess!")
plt.plot(x_tess, y_tess, marker="o", ls="none", color="firebrick")
plt.plot(x_tess, sampled_flare, ls="-", color="darkgrey")
plt.xlabel("Time [days]", fontsize=12)
plt.ylabel("Normalized SAP Flux Minus One [$Delta$F/F-1]", fontsize=12)
plt.show()

#Now, let's use our good guess above to get an even better guess!
popt_tess, pcov = curve_fit(davenport_flare_model, x_tess, y_tess, p0=[0.005, 0.6, 11.5], method="dogbox", maxfev=5000)

print popt_tess, "just copy-paste this into next iteration below" #repeat this process as many times as necessary to get the curve_fit routine to converge
# sometimes the routine will not converge by maxfev=5000 maximum function evaluations, can set larger if needed


#final try, best fit to Davenport template
popt_tess = [0.00373696, 0.63415, 15.1136] #[width-in-FWHMs, peak flare amplitude, unitless time-of-peak height]
sampled_flare = davenport_flare_model(x_tess, *popt_tess)

plt.title("Second attempt, as good a fit as possible")
plt.plot(x_tess, y_tess, marker="o", ls="none", color="firebrick")
plt.plot(x_tess, sampled_flare, ls="-", color="darkgrey")
plt.xlabel("Time [days]", fontsize=12)
plt.ylabel("Normalized SAP Flux Minus One [$Delta$F/F-1]", fontsize=12)
plt.show()
