import glob
import copy
import numpy as np
import os
import astropy.table as tbl
from astropy import time, coordinates as coord, units as u
from paper_data_read_functions import read_table_one
from paper_data_read_functions import read_table_two as read_table_two
from astropy.stats import LombScargle
from astropy.io import fits
from scipy.optimize import leastsq
import matplotlib.pyplot as plt
from scipy.stats import sigmaclip
import scipy.signal
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit
import glob

def linear(x, m, b):
    return m*x + b

def davenport_flare_model(epochs, width, ampl, peak_time):

    if width==0.0 and ampl==0.0 and peak_time==0.0:
        return np.zeros(len(epochs))
    elif ampl<0.000001:
        ampl=100000.0
    else:
        pass
    
    # See Davenport et al 2014, ApJ 797, 2
    t = copy.deepcopy(epochs)
    t/=width
    #assume a gaussian-distribution 1-5mins for risetime, 20-30mins decay
    try:
        flare_y = 0.689*np.exp(-1.6*(t-peak_time),dtype=np.float64) + 0.303*np.exp(-0.2783*(t-peak_time),dtype=np.float64)
    except (RuntimeWarning):
        print np.exp(-1.6*(t-peak_time),dtype=np.float64)
        print np.exp(-0.2783*(t-peak_time),dtype=np.float64)
        exit()
    flare_y[(t-peak_time)<0] = 1.0 + (1.941)*(t-peak_time)[(t-peak_time)<0] - 0.175*((t-peak_time)[(t-peak_time)<0]**2) - 2.246*((t-peak_time)[(t-peak_time)<0]**3) - 1.125*((t-peak_time)[(t-peak_time)<0]**4)

    flare_y[flare_y<0.000001]= 0.000001 #set all flare points that would otherwise be negative to val near zero
    flare_y = flare_y*ampl #adjust flare peak amplitude
    #rise; FWHMs not minutes
    return flare_y

def two_peak_dav_flare_model(epochs, width1, ampl1, peak_time1, width2, ampl2, peak_time2):
    flare_y1 = davenport_flare_model(epochs, width1, ampl1, peak_time1)
    flare_y2 = davenport_flare_model(epochs, width2, ampl2, peak_time2)
    flare_y = flare_y1 + flare_y2
    return flare_y

def three_peak_dav_flare_model(epochs, width1, ampl1, peak_time1, width2, ampl2, peak_time2, width3, ampl3, peak_time3):
    flare_y1 = davenport_flare_model(epochs, width1, ampl1, peak_time1)
    flare_y2 = davenport_flare_model(epochs, width2, ampl2, peak_time2)
    flare_y3 = davenport_flare_model(epochs, width3, ampl3, peak_time3)
    flare_y = flare_y1 + flare_y2 + flare_y3
    return flare_y

def four_peak_dav_flare_model(epochs, width1, ampl1, peak_time1, width2, ampl2, peak_time2, width3, ampl3, peak_time3, width4, ampl4, peak_time4):
    flare_y1 = davenport_flare_model(epochs, width1, ampl1, peak_time1)
    flare_y2 = davenport_flare_model(epochs, width2, ampl2, peak_time2)
    flare_y3 = davenport_flare_model(epochs, width3, ampl3, peak_time3)
    flare_y4 = davenport_flare_model(epochs, width3, ampl3, peak_time3)
    flare_y = flare_y1 + flare_y2 + flare_y3 + flare_y4
    return flare_y

def compute_1sigma_CI(input_array):

    sorted_input_array = np.sort(input_array)

    low_ind = int(0.16*len(input_array))
    high_ind = int(0.84*len(input_array))

    bot_val = (sorted_input_array[:low_ind])[-1]
    top_val = (sorted_input_array[high_ind:])[0]

    bot_arr_err = abs(np.nanmedian(input_array) - bot_val)
    top_arr_err = abs(np.nanmedian(input_array) - top_val)

    return (np.nanmedian(input_array), bot_arr_err, top_arr_err)

def get_ATLAS_gmag():
    atl_TIC=[]
    atl_RA=[]
    atl_Dec=[]
    atl_g=[]
    atl_dg=[]
    atl_r=[]
    atl_dr=[]
    atl_i=[]
    atl_di=[]
    atl_dist=[]
    with open("EVRYFLARE_atlas_xmatch.csv","r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            atl_TIC.append(int(lines.split(",")[0]))
            atl_RA.append(float(lines.split(",")[1]))
            atl_Dec.append(float(lines.split(",")[2]))
            atl_g.append(float(lines.split(",")[3]))
            atl_dg.append(float(lines.split(",")[4]))
            atl_r.append(float(lines.split(",")[5]))
            atl_dr.append(float(lines.split(",")[6]))
            atl_i.append(float(lines.split(",")[7]))
            atl_di.append(float(lines.split(",")[8]))
            atl_dist.append(float(lines.split(",")[9]))
    atl_TIC=np.array(atl_TIC)
    atl_RA=np.array(atl_RA)
    atl_Dec=np.array(atl_Dec)
    atl_g=np.array(atl_g)
    atl_dg=np.array(atl_dg)
    atl_r=np.array(atl_r)
    atl_dr=np.array(atl_dr)
    atl_i=np.array(atl_i)
    atl_di=np.array(atl_di)
    atl_dist=np.array(atl_dist)
    
    return (atl_TIC, atl_g, atl_dg)

def get_tess_lcv(fits_table_filename):

    hdulist = fits.open(fits_table_filename)  # open a FITS file

    data = hdulist[1].data  # assume the first extension is a table

    # get star time series 
    tess_bjd = hdulist[1].data['TIME']
    sap_flux = hdulist[1].data['SAP_FLUX']
    sap_flux_err = hdulist[1].data['SAP_FLUX_ERR']
    
    sap_norm_flux=sap_flux/np.nanmedian(sap_flux)
    sap_norm_flux_err=sap_flux_err/np.nanmedian(sap_flux)

    pdcsap_flux = hdulist[1].data['PDCSAP_FLUX']
    flags = hdulist[1].data['QUALITY']

    # convert to numpy arrays:
    tess_bjd=np.array(tess_bjd)
    sap_norm_flux=np.array(sap_norm_flux)
    sap_norm_flux_err = np.array(sap_norm_flux_err)
    flags=np.array(flags)

    temp = np.vstack((tess_bjd,sap_norm_flux,sap_norm_flux_err,flags)).T
    tess_bjd = np.array([x[0] for x in temp if np.isnan(x[1])==False])
    sap_norm_flux = np.array([x[1] for x in temp if np.isnan(x[1])==False])
    sap_norm_flux_err = np.array([x[2] for x in temp if np.isnan(x[1])==False])
    flags = np.array([x[3] for x in temp if np.isnan(x[1])==False])
    
    #optional smoothing with SG filter:
    #sg_whitened_flux, sg_filter = SG_lcv_smoother(tess_bjd,sap_norm_flux,fits_table_filename)
    
    #return (tess_bjd, sap_norm_flux, flags)
    return (tess_bjd, sap_norm_flux, sap_norm_flux_err, flags)

def build_tess_lightcurve(TID,PATH):
    #print glob.glob(PATH+"*"+str(TID)+"*lc.fits")
    #exit()
    tess_lcvs = glob.glob(PATH+"*lc.fits") #load every TESS lcv, select each flare star from this list
    tic_id_arr=[]
    for i in range(len(tess_lcvs)):
        #print int(tess_lcvs[i].split("-")[2])
        tic_id_arr.append(int(tess_lcvs[i].split("-")[2]))
    tic_id_arr=np.array(tic_id_arr)
    indices_tic_id = np.arange(len(tic_id_arr))
    
    targ_tic_ids = copy.deepcopy(tic_id_arr)[tic_id_arr==TID]
    targ_inds = indices_tic_id[tic_id_arr==TID]
    #print ""

    sector_list=[]
    
    count=0
    for j in targ_inds:
        #print j,TID,tic_id_arr[j]
        #print int(tess_lcvs[j].split("-")[-4].replace("s",""))
        sector_list.append(int(tess_lcvs[j].split("-")[-4].replace("s","")))
        tess_bjd_part, sap_flux_part, sap_flux_err_part, flags_part = get_tess_lcv(tess_lcvs[j])
        if count==0:
            tess_bjd=tess_bjd_part
            sap_flux=sap_flux_part
            sap_flux_err=sap_flux_err_part
            flags=flags_part
        else:
            tess_bjd=np.concatenate((tess_bjd,tess_bjd_part))
            sap_flux=np.concatenate((sap_flux,sap_flux_part))
            sap_flux_err=np.concatenate((sap_flux_err,sap_flux_err_part))
            flags=np.concatenate((flags,flags_part))
        count+=1

    tess_bjd = copy.deepcopy(tess_bjd)
    sap_flux = copy.deepcopy(sap_flux)
    sap_flux_err = copy.deepcopy(sap_flux_err)
    
    first_sector = np.min(sector_list)
    last_sector = np.max(sector_list)

    return (tess_bjd,sap_flux,sap_flux_err,first_sector,last_sector)

_lambda = np.linspace(1.0, 1500.0, num=1000) # nm
Lambda = copy.deepcopy(_lambda)

def blackbody_spectrum(_lambda, temp):
    __lambda = copy.deepcopy(_lambda)
    __lambda *= (10.0**(-9.0)) # from nm to m
    h = 6.62607004 * 10.0**(-34.0) # Planck's constant m^2 kg / s
    c = 3.0*(10.0**8.0) #m/s
    k_B = 1.38064852 * 10.0**(-23.0) # Boltzmann constant (m^2 kg / s^2 K)
    T = temp #9000.0 # K

    #x = np.exp(h*c/(__lambda*k_B*T),dtype=np.float128)-1
    #print x
    
    flux = 2.0*h*(c**2.0) / ((__lambda**5.0)*(np.exp(h*c/(__lambda*k_B*T))-1.0))
    #plt.title(temp)
    #plt.plot(_lambda, flux, marker="+",ls="none",color="black")
    #plt.plot(_lambda[x>(7.3147732e+190)], flux[x>(7.3147732e+190)], marker="+",ls="none",color="red")
    #plt.show()
    #exit()
    
    return flux

# Green filters:
filt_wavelength=[]
filt_response=[]
with open("./run4/ctio_omega_g.csv","r") as FILTER:
    for lines in FILTER:
        filt_wavelength.append(float(lines.split(",")[0]))
        filt_response.append(0.01*float(lines.split(",")[1].rstrip("\n")))
filt_wavelength=np.array(filt_wavelength)
filt_response=np.array(filt_response)

CCD_wavelength=[]
CCD_response=[]
with open("./run4/ML290050_QE.csv","r") as CCD:
    for lines in CCD:
        CCD_wavelength.append(float(lines.split(",")[0]))
        CCD_response.append(0.01*float(lines.split(",")[1].rstrip("\n")))
CCD_wavelength=np.array(CCD_wavelength)
CCD_response=np.array(CCD_response)

interp_filt=interp1d(filt_wavelength,filt_response,kind="linear",fill_value=0.0,bounds_error=False)
interp_CCD=interp1d(CCD_wavelength,CCD_response,kind="linear",fill_value=0.0,bounds_error=False)

g_response_fn = interp_filt(Lambda)*interp_CCD(Lambda)

#A = np.trapz(g_response_fn,Lambda)
#B = np.trapz(filt_response,filt_wavelength)

in_gband = g_response_fn[g_response_fn > 0.05]
g_response_fn/=np.average(in_gband)

# TESS response function:
TESS_wavelength=[]
TESS_response=[]
with open("./run4/tess-response-function-v1.0.csv","r") as FILTER:
    next(FILTER) #1
    next(FILTER) #2
    next(FILTER) #3
    next(FILTER) #4
    next(FILTER) #5
    next(FILTER) #6
    next(FILTER) #7
    next(FILTER) #8
    next(FILTER) #9
    
    for lines in FILTER:
        TESS_wavelength.append(float(lines.split(",")[0]))
        TESS_response.append(float(lines.split(",")[1].rstrip("\n")))
TESS_wavelength=np.array(TESS_wavelength)
TESS_response=np.absolute(np.array(TESS_response))

interp_TESS = interp1d(TESS_wavelength,TESS_response,kind="linear",fill_value=0.0,bounds_error=False)

TESS_response_fn = interp_TESS(Lambda)

in_Tband = TESS_response_fn[TESS_response_fn > 0.05]
TESS_response_fn/=np.average(in_Tband)

BB_temps = np.linspace(500.0,60000.0,num=6000) # set to 2000 steps!!!

flux10K = blackbody_spectrum(_lambda, 10000)
flux30K = blackbody_spectrum(_lambda, 30000)

UV_flux_10K = np.trapz(flux10K[(_lambda>=100.0)&(_lambda<=280.0)], _lambda[(_lambda>=100.0)&(_lambda<=280.0)])
tot_flux_10K = np.trapz(flux10K, _lambda)

UV_flux_30K = np.trapz(flux30K[(_lambda>=100.0)&(_lambda<=280.0)], _lambda[(_lambda>=100.0)&(_lambda<=280.0)])
tot_flux_30K = np.trapz(flux30K, _lambda)

frac_UVC_10K = UV_flux_10K/tot_flux_10K
frac_UVC_30K = UV_flux_30K/tot_flux_30K


print UV_flux_10K/tot_flux_10K,"10,000 K in UVC"
print UV_flux_30K/tot_flux_30K,"30,000 K in UVC"

flux_in_g_10K = flux10K*g_response_fn
flux_in_g_30K = flux30K*g_response_fn

area_in_g_10K = np.trapz(flux_in_g_10K, _lambda)
area_in_g_30K = np.trapz(flux_in_g_30K, _lambda)

frac_g_10K = area_in_g_10K/tot_flux_10K
frac_g_30K = area_in_g_30K/tot_flux_30K

print area_in_g_10K/tot_flux_10K,"10,000 K in g"
print area_in_g_30K/tot_flux_30K,"30,000 K in g"

print "how much more UVC than g 10K",frac_UVC_10K/frac_g_10K
print "how much more UVC than g 30K",frac_UVC_30K/frac_g_30K
#exit()

ratios=[]
for i in range(len(BB_temps)):
    flux = blackbody_spectrum(_lambda, BB_temps[i])

    flux_in_g = flux*g_response_fn
    flux_in_T = flux*TESS_response_fn

    area_in_g = np.trapz(flux_in_g, _lambda)
    area_in_T = np.trapz(flux_in_T, _lambda)

    ratios.append(area_in_g/area_in_T)
    #print BB_temps[i],"K"
ratios=np.array(ratios)

ratios[0] = 0.0
ratios[-1]=10.0

flux10 = blackbody_spectrum(_lambda, 10000.0)
flux30 = blackbody_spectrum(_lambda, 30000.0)

fig, ax = plt.subplots(figsize=(7,5))

plt.plot(_lambda, g_response_fn/np.max(g_response_fn),color="lightgrey",linewidth=2)
plt.plot(_lambda, TESS_response_fn/np.max(TESS_response_fn),color="lightgrey",linewidth=2)

plt.plot(np.linspace(373.5,1123.0,num=100), np.zeros(100), ls="-", color="white",linewidth=3.0)

plt.plot(_lambda, flux30/np.max(flux30), color="mediumslateblue",linewidth=2)
plt.plot(_lambda, 0.045*(flux10/np.max(flux10)), color="darkorange",linewidth=2.3)

plt.text(410,1.01,"Evryscope",color="grey",fontsize=14,alpha=0.75)
plt.text(940,0.93,"TESS",color="grey",fontsize=14,alpha=0.75)

plt.text(144,0.81,"30,000 K",color="mediumslateblue",fontsize=14)
plt.text(1150,0.025,"10,000 K",color="darkorange",fontsize=14)
plt.ylabel("Normalized flux",fontsize=16)
plt.xlabel("Wavelength [nm]",fontsize=16)

plt.ylim(-0.05,1.1)
plt.tight_layout()
plt.savefig("flare_teff_comparison_v1.png")
plt.show()

for i in range(len(_lambda)):
    info = str(_lambda[i])+","+str(flux30[i]/np.max(flux30))+","+str(0.045*(flux10[i]/np.max(flux10)))+","+str(g_response_fn[i]/np.max(g_response_fn))+","+str(TESS_response_fn[i]/np.max(TESS_response_fn))+"\n"
    with open("four_lines_aapf.csv","a") as SMALL:
        SMALL.write(info)
exit()

fig, ax = plt.subplots(figsize=(7,5))

resp1 = g_response_fn*(flux10/np.max(flux10))
resp2 = g_response_fn*(flux30/np.max(flux30))
resp3 = TESS_response_fn*(flux10/np.max(flux10))
resp4 = TESS_response_fn*(flux30/np.max(flux30))

plt.plot(_lambda, resp1, color="darkorange",linewidth=2)
plt.plot(_lambda, resp2*18, color="mediumslateblue",linewidth=2)
plt.plot(_lambda, resp3, color="darkorange",linewidth=2)
plt.plot(_lambda, resp4*18, color="mediumslateblue",linewidth=2)

#plt.text(630,0.03,"30,000 K",color="mediumslateblue",fontsize=14)
#plt.text(1150,0.09,"10,000 K",color="darkorange",fontsize=14)
plt.ylabel("Normalized flux",fontsize=16)
plt.xlabel("Wavelength [nm]",fontsize=16)

plt.ylim(-0.05,1.1)
plt.savefig("flare_teff_comparison_v2.png")
plt.show()

exit()

fig, ax = plt.subplots(figsize=(7,5))
#plt.axis('off')

#ax1 = fig.add_subplot(2,3,1)

plt.plot(ratios, BB_temps, linewidth=2, color="black")
plt.axvline(2.125,color="red",ls="--",linewidth=2.5)
plt.axvspan(2.4,3.4,color="red",alpha=0.333)

plt.text(2.27, 29900,r"Asymptotic limit (T$\rightarrow \infty$)",color="red",fontsize=14, rotation=90)
plt.text(1.999, 29000,"$R$ poorly constrains $T_\mathrm{Eff}$", color="red", fontsize=14, rotation=90)

plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.xlabel("$R$ [$E_\mathrm{Evry}$ / $E_\mathrm{TESS}$]",fontsize=16)
plt.ylabel("$T_\mathrm{Eff}$ [K]",fontsize=16)


plt.xlim(-0.16, 2.9)
plt.ylim(-500, 50000)

plt.tight_layout()
plt.savefig("T_func_R_plot.png")
plt.show()
#exit()

get_teff = interp1d(ratios, BB_temps, kind="linear")
#exit()

######################################################################

