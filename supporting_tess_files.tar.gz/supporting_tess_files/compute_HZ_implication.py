import glob
import copy
import numpy as np
import os
from astropy.stats import LombScargle
import matplotlib.pyplot as plt
from scipy.stats import sigmaclip
import scipy.signal
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit
import matplotlib
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)

i=[] #0
TIC_ID=[] #1
RA=[] #2
Dec=[] #3
Year=[] #4
Mon=[] #5
Day=[] #6
HR=[] #7
Min=[] #8
g_mags=[] #9
TESS_mags=[] #10
distance=[] #11
SpT=[] #12
mass=[] #13
Prot=[] #14
Ro=[] #15
Evry_Erg=[] #16
e_Evry_Erg=[] #17
TESS_erg=[] #18
e_TESS_Erg=[] #19
evr_peakFF=[] #20
tess_peakFF=[] #21
n_peaks=[] #22
tot_BB_data=[] #23
e_tot_BB_data=[] #24
tot_BB_data_trap=[] #25
e_tot_BB_data_trap=[] #26
E_tot_BB_data_trap=[] #27
tot_BB_sampl=[] #28
e_tot_BB_sampl=[] #29
E_tot_BB_sampl=[] #30
FWHM_BB_data=[] #31
e_FWHM_BB_data=[] #32
FWHM_BB_sampl=[] #33
e_FWHM_BB_sampl=[] #34
E_FWHM_BB_sampl=[] #35
FWHM=[] #36
impulse=[] #37

with open("evryflare_III_table_I.csv","r") as INFILE:
    next(INFILE)
    for lines in INFILE:
        i.append(int(lines.split(",")[0])) #0
        TIC_ID.append(int(lines.split(",")[1])) #1
        RA.append(float(lines.split(",")[2])) #2
        Dec.append(float(lines.split(",")[3])) #3
        Year.append(int(lines.split(",")[4])) #4
        Mon.append(int(lines.split(",")[5])) #5
        Day.append(int(lines.split(",")[6])) #6
        HR.append(int(lines.split(",")[7])) #7
        Min.append(int(lines.split(",")[8])) #8
        g_mags.append(float(lines.split(",")[9])) #9
        TESS_mags.append(float(lines.split(",")[10])) #10
        distance.append(float(lines.split(",")[11])) #11
        SpT.append(str(lines.split(",")[12])) #12
        mass.append(float(lines.split(",")[13])) #13
        Prot.append(float(lines.split(",")[14])) #14
        Ro.append(float(lines.split(",")[15])) #15
        Evry_Erg.append(float(lines.split(",")[16])) #16
        e_Evry_Erg.append(float(lines.split(",")[17])) #17
        TESS_erg.append(float(lines.split(",")[18])) #18
        e_TESS_Erg.append(float(lines.split(",")[19])) #19
        evr_peakFF.append(float(lines.split(",")[20])) #20
        tess_peakFF.append(float(lines.split(",")[21])) #21
        n_peaks.append(int(lines.split(",")[22])) #22
        tot_BB_data.append(float(lines.split(",")[23])) #23
        e_tot_BB_data.append(float(lines.split(",")[24])) #24
        tot_BB_data_trap.append(float(lines.split(",")[25])) #25
        e_tot_BB_data_trap.append(float(lines.split(",")[26])) #26
        E_tot_BB_data_trap.append(float(lines.split(",")[27])) #27
        tot_BB_sampl.append(float(lines.split(",")[28])) #28
        e_tot_BB_sampl.append(float(lines.split(",")[29])) #29
        E_tot_BB_sampl.append(float(lines.split(",")[30])) #30
        FWHM_BB_data.append(float(lines.split(",")[31])) #31
        e_FWHM_BB_data.append(float(lines.split(",")[32])) #32
        FWHM_BB_sampl.append(float(lines.split(",")[33])) #33
        e_FWHM_BB_sampl.append(float(lines.split(",")[34])) #34
        E_FWHM_BB_sampl.append(float(lines.split(",")[35])) #35
        FWHM.append(float(lines.split(",")[36])) #36
        impulse.append(float(lines.split(",")[37])) #37
i = np.array(i)        
TIC_ID=np.array(TIC_ID)
mass = np.array(mass)
FWHM = np.array(FWHM)
g_mags= np.array(g_mags)
distance= np.array(distance)
Evry_Erg = np.array(Evry_Erg)
TESS_Erg = np.array(TESS_erg)
e_Evry_Erg = np.array(e_Evry_Erg)
Evry_Erg_bol = np.log10((10.0**Evry_Erg)/0.19)
SpT = np.array(SpT)
FWHM_BB_data = np.array(FWHM_BB_data)
tot_BB_data = np.array(tot_BB_data)
e_FWHM_BB_data = np.array(e_FWHM_BB_data)
e_tot_BB_data = np.array(e_tot_BB_data)
FWHM_BB_sampl = np.array(FWHM_BB_sampl)
tot_BB_sampl = np.array(tot_BB_sampl)
impulse = np.array(impulse)
evr_peakFF = np.array(evr_peakFF)
tess_peakFF = np.array(tess_peakFF)
color = evr_peakFF - tess_peakFF
n_peaks = np.array(n_peaks).astype(float)
Ro = np.array(Ro)
Prot = np.array(Prot)

e_FWHM_BB_data[e_FWHM_BB_data<300.0]=300.0
e_tot_BB_data[e_tot_BB_data<300.0]=300.0

print len(np.unique(TIC_ID)),"uniq stars"

def compute_1sigma_CI(input_array):

    sorted_input_array = np.sort(input_array)

    low_ind = int(0.16*len(input_array))
    high_ind = int(0.84*len(input_array))

    bot_val = (sorted_input_array[:low_ind])[-1]
    top_val = (sorted_input_array[high_ind:])[0]

    bot_arr_err = abs(np.nanmedian(input_array) - bot_val)
    top_arr_err = abs(np.nanmedian(input_array) - top_val)

    return (np.mean(input_array), bot_arr_err, top_arr_err)

def get_FWHM_energy():
    fwhm_i=[]
    fwhm_energy=[]
    with open("addendum_FWHM_energy.csv") as INFILE:
        for lines in INFILE:
            fwhm_i.append(int(lines.split(",")[0]))
            fwhm_energy.append(float(lines.split(",")[1].rstrip("\n")))
    fwhm_i=np.array(fwhm_i)
    fwhm_energy=np.array(fwhm_energy)

    return (fwhm_i, fwhm_energy)


def blackbody_spectrum(_lambda, temp):
    __lambda = copy.deepcopy(_lambda)
    __lambda *= (10.0**(-9.0)) # from nm to m
    h = 6.62607004 * 10.0**(-34.0) # Planck's constant m^2 kg / s
    c = 3.0*(10.0**8.0) #m/s
    k_B = 1.38064852 * 10.0**(-23.0) # Boltzmann constant (m^2 kg / s^2 K)
    T = temp #9000.0 # K

    #x = np.exp(h*c/(__lambda*k_B*T),dtype=np.float128)-1
    #print x
    
    flux = 2.0*h*(c**2.0) / ((__lambda**5.0)*(np.exp(h*c/(__lambda*k_B*T))-1.0))
    #plt.title(temp)
    #plt.plot(_lambda, flux, marker="+",ls="none",color="black")
    #plt.plot(_lambda[x>(7.3147732e+190)], flux[x>(7.3147732e+190)], marker="+",ls="none",color="red")
    #plt.show()
    #exit()
    
    return flux

_lambda = np.linspace(1.0, 1500.0, num=1000) # nm
Lambda = copy.deepcopy(_lambda)

# Green filters:
filt_wavelength=[]
filt_response=[]
with open("ctio_omega_g.csv","r") as FILTER:
    for lines in FILTER:
        filt_wavelength.append(float(lines.split(",")[0]))
        filt_response.append(0.01*float(lines.split(",")[1].rstrip("\n")))
filt_wavelength=np.array(filt_wavelength)
filt_response=np.array(filt_response)

CCD_wavelength=[]
CCD_response=[]
with open("ML290050_QE.csv","r") as CCD:
    for lines in CCD:
        CCD_wavelength.append(float(lines.split(",")[0]))
        CCD_response.append(0.01*float(lines.split(",")[1].rstrip("\n")))
CCD_wavelength=np.array(CCD_wavelength)
CCD_response=np.array(CCD_response)

interp_filt=interp1d(filt_wavelength,filt_response,kind="linear",fill_value=0.0,bounds_error=False)
interp_CCD=interp1d(CCD_wavelength,CCD_response,kind="linear",fill_value=0.0,bounds_error=False)

g_response_fn = interp_filt(Lambda)*interp_CCD(Lambda)

A = np.trapz(g_response_fn,Lambda)
B = np.trapz(filt_response,filt_wavelength)

in_gband = g_response_fn[g_response_fn > 0.05]
g_response_fn/=np.average(in_gband)

#plt.plot(_lambda, g_response_fn)
#plt.show()
#print("\n")

E_M0 = 10.0**34.0 #erg
E_M4 = 10.0**33.0 #erg

Teff_M0 = 14625.0 #Teff largest flare from an M0 per month
Teff_M4 = 10887.0 #Teff largest flare from an M4 per month

bbflux_M4 = blackbody_spectrum(_lambda, Teff_M4)
bbflux_M0 = blackbody_spectrum(_lambda, Teff_M0)
bbflux_canonical = blackbody_spectrum(_lambda, 9000.0)

frac_UVC = np.trapz(bbflux_canonical[(_lambda>240.0)&(_lambda<280.0)], _lambda[(_lambda>240.0)&(_lambda<280.0)])/np.trapz(bbflux_canonical, _lambda)

frac_UVB = np.trapz(bbflux_canonical[(_lambda>280.0)&(_lambda<315.0)], _lambda[(_lambda>280.0)&(_lambda<315.0)])/np.trapz(bbflux_canonical, _lambda)

print "\nUV-B", np.round(frac_UVB,3)
print "\nUV-C", np.round(frac_UVC,3)
exit()

frac_g_M4 = np.trapz(bbflux_M4*g_response_fn, _lambda)/np.trapz(bbflux_M4, _lambda)
frac_UVC_M4 = np.trapz(bbflux_M4[(_lambda>100.0)&(_lambda<280.0)], _lambda[(_lambda>100.0)&(_lambda<280.0)])/np.trapz(bbflux_M4, _lambda)

frac_g_M0 = np.trapz(bbflux_M0*g_response_fn, _lambda)/np.trapz(bbflux_M0, _lambda)
frac_UVC_M0 = np.trapz(bbflux_M0[(_lambda>100.0)&(_lambda<280.0)], _lambda[(_lambda>100.0)&(_lambda<280.0)])/np.trapz(bbflux_M0, _lambda)

#frac_g_canonical =np.trapz(bbflux_canonical[(_lambda>400.0)&(_lambda<550.0)], _lambda[(_lambda>400.0)&(_lambda<550.0)])/np.trapz(bbflux_canonical, _lambda)

print frac_g_M4
print frac_UVC_M4
print frac_g_M0
print frac_UVC_M0

fwhm_i, fwhm_energy = get_FWHM_energy()

print len(fwhm_i), len(fwhm_energy), len(FWHM_BB_data)
#FWHM

UVC_energy=[]
bolometric_energy=[]
for s in range(len(FWHM_BB_data)):
    #print "here"
    Eg_target = fwhm_energy[s]
    Tot_Eg_target = 10.0**Evry_Erg[s]
    
    Teff_target = FWHM_BB_data[s]
    bbflux_target = blackbody_spectrum(_lambda, Teff_target)

    Tot_Teff_target = tot_BB_data[s]
    Tot_bbflux_target = blackbody_spectrum(_lambda, Tot_Teff_target)
    
    frac_g_target = np.trapz(bbflux_target*g_response_fn, _lambda)/np.trapz(bbflux_target, _lambda)
    frac_UVC_target = np.trapz(bbflux_target[(_lambda>100.0)&(_lambda<280.0)], _lambda[(_lambda>100.0)&(_lambda<280.0)])/np.trapz(bbflux_target, _lambda)

    UVC_energy.append(np.round(np.log10(Eg_target*(frac_UVC_target/frac_g_target)),2))
    
    opt_over_bol = 0.7
    Tot_frac_g_target = np.round((np.trapz(Tot_bbflux_target*g_response_fn, _lambda)/np.trapz(Tot_bbflux_target, _lambda))*opt_over_bol,3)
    bol_E = np.round(np.log10(Tot_Eg_target/Tot_frac_g_target),2)
    print np.round(np.log10(Tot_Eg_target),2), bol_E, Tot_frac_g_target
    bolometric_energy.append(bol_E)
bolometric_energy = np.array(bolometric_energy)
#print bolometric_energy[]
#exit()
print "number of superflares", len(bolometric_energy[bolometric_energy>=33.0])
print "numberof stars", len(np.unique(TIC_ID[bolometric_energy>=33.0]))

sFWHM = FWHM*60.0
UVC_energy = 10.0**np.array(UVC_energy)
UVC_flux_Watts = (UVC_energy*(10.0**(-7)))/(sFWHM)

#print len(UVC_energy),"uv"

print np.mean(UVC_flux_Watts[mass<=0.42]),"J"
print np.mean(UVC_flux_Watts[mass>0.42]),"J"
print np.mean(UVC_flux_Watts[mass>0.42])/np.mean(UVC_flux_Watts[mass<=0.42])

print np.mean(mass[mass<=0.42]),"msol"
print np.mean(mass[mass>0.42]),"msol"

inner_hz_distance=[]
inner_hz_mass=[]
with open("K13_HZ_inner_edge.csv","r") as INFILE:
    for lines in INFILE:
        inner_hz_distance.append(float(lines.split(",")[0]))
        inner_hz_mass.append(float(lines.split(",")[1]))
inner_hz_distance=np.array(inner_hz_distance)
inner_hz_mass=np.array(inner_hz_mass)

outer_hz_distance=[]
outer_hz_mass=[]
with open("K13_HZ_outer_edge.csv","r") as INFILE:
    for lines in INFILE:
        outer_hz_distance.append(float(lines.split(",")[0]))
        outer_hz_mass.append(float(lines.split(",")[1]))
outer_hz_distance=np.array(outer_hz_distance)
outer_hz_mass=np.array(outer_hz_mass)

x_au = np.linspace(0.04, 2.2, num=5000)

interp_inner_HZ = interp1d(inner_hz_distance, inner_hz_mass, kind="linear",bounds_error=False, fill_value="extrapolate")
interp_outer_HZ = interp1d(outer_hz_distance, outer_hz_mass, kind="linear",bounds_error=False, fill_value="extrapolate")

inner_HZ_mass = interp_inner_HZ(x_au)
outer_HZ_mass = interp_outer_HZ(x_au)

mid_HZ_mass = np.average((inner_HZ_mass, outer_HZ_mass),axis=0)



plt.axhline(0.55,color="purple")
plt.axhline(0.31,color="orange")
plt.loglog(inner_hz_distance, inner_hz_mass, color="blue")
plt.loglog(outer_hz_distance, outer_hz_mass, color="red")
plt.loglog(x_au, mid_HZ_mass, color="limegreen")
plt.show()
#exit()

AU_to_meter = 1.496*(10.0**11.0) #meter = 1 AU

early_HZ_dist = 0.332758*AU_to_meter
late_HZ_dist = 0.153018*AU_to_meter

print "early indiv.",np.mean(UVC_flux_Watts[mass>0.42])/(4.0*np.pi*(early_HZ_dist**2.0)),"W/m^2"
print "late indiv.", np.mean(UVC_flux_Watts[mass<=0.42])/(4.0*np.pi*(late_HZ_dist**2.0)),"W/m^2"

interp_HZdist_AU = interp1d(mid_HZ_mass, x_au,  kind="linear",bounds_error=False, fill_value="extrapolate")

HZ_dist_m = interp_HZdist_AU(mass)*AU_to_meter

plt.axhline(0.55,color="purple")
plt.axhline(0.31,color="orange")
plt.loglog(inner_hz_distance, inner_hz_mass, color="blue")
plt.loglog(outer_hz_distance, outer_hz_mass, color="red")
plt.loglog(x_au, mid_HZ_mass, color="limegreen")
plt.loglog(interp_HZdist_AU(mass), mass, marker="o",ls="none",color="darkorange")
plt.show()
#exit()

UVC_surface_flux = UVC_flux_Watts/(4.0*np.pi*(HZ_dist_m**2.0))

for h in range(len(TIC_ID)):
    info = str(i[h])+","+str(TIC_ID[h])+","+str(np.log10(UVC_energy[h]))+","+str(UVC_surface_flux[h])+","+str(mass[h])+"\n"
    #with open("HZ_fluxes.csv","a") as FLUXOUT:
    #    FLUXOUT.write(info)

print "late cong.:",np.median(UVC_surface_flux[mass<=0.42]),"W/m^2"
print "early cong.:",np.median(UVC_surface_flux[mass>0.42]),"W/m^2"

plt.hist(UVC_surface_flux[mass<=0.42],alpha=0.77,label="late",normed=True)
plt.hist(UVC_surface_flux[mass>0.42],alpha=0.5,label="early",normed=True)
plt.semilogx(1.0,0.0,alpha=0.0)
plt.show()
