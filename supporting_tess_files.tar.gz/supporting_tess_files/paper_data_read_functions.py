import numpy as np
import glob
import copy
import os
import numpy as np
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
from scipy.stats import sigmaclip
from astropy.io import fits
import astropy.stats as astrostat
from matplotlib.ticker import MultipleLocator, FormatStrFormatter, FixedLocator

from astropy.coordinates import SkyCoord  # High-level coordinates
from astropy.coordinates import ICRS, Galactic, FK4, FK5  # Low-level frames
from astropy.coordinates import Angle, Latitude, Longitude  # Angles
import astropy.units as u
from scipy.optimize import curve_fit

def get_mit_tid_ra_dec():
    mit_tid=[]
    mit_ra=[]
    mit_dec=[]
    mit_sector=[]
    with open("./raw_files/all_targets_S001_v1.txt","r") as T_1:
        next(T_1)
        next(T_1)
        for lines in T_1:
            mit_tid.append(int(lines.split("\t")[0]))
            mit_ra.append(float(lines.split("\t")[4]))
            mit_dec.append(float(lines.split("\t")[5].rstrip("\n")))
            mit_sector.append(1)
    with open("./raw_files/all_targets_S002_v1.txt","r") as T_2:
        next(T_2)
        next(T_2)
        for lines in T_2:
            mit_tid.append(int(lines.split("\t")[0]))
            mit_ra.append(float(lines.split("\t")[4]))
            mit_dec.append(float(lines.split("\t")[5].rstrip("\n")))
            mit_sector.append(2)
    with open("./raw_files/all_targets_S003_v1.txt","r") as T_3:
        next(T_3)
        next(T_3)
        for lines in T_3:
            mit_tid.append(int(lines.split("\t")[0]))
            mit_ra.append(float(lines.split("\t")[4]))
            mit_dec.append(float(lines.split("\t")[5].rstrip("\n")))
            mit_sector.append(3)
    with open("./raw_files/all_targets_S004_v1.txt","r") as T_4:
        next(T_4)
        next(T_4)
        for lines in T_4:
            mit_tid.append(int(lines.split("\t")[0]))
            mit_ra.append(float(lines.split("\t")[4]))
            mit_dec.append(float(lines.split("\t")[5].rstrip("\n")))
            mit_sector.append(4)
    with open("./raw_files/all_targets_S005_v1.txt","r") as T_5:
        next(T_5)
        next(T_5)
        for lines in T_5:
            mit_tid.append(int(lines.split("\t")[0]))
            mit_ra.append(float(lines.split("\t")[4]))
            mit_dec.append(float(lines.split("\t")[5].rstrip("\n")))
            mit_sector.append(5)
    with open("./raw_files/all_targets_S006_v1.txt","r") as T_6:
        next(T_6)
        next(T_6)
        for lines in T_6:
            mit_tid.append(int(lines.split("\t")[0]))
            mit_ra.append(float(lines.split("\t")[4]))
            mit_dec.append(float(lines.split("\t")[5].rstrip("\n")))
            mit_sector.append(6)
    mit_tid=np.array(mit_tid)
    mit_ra=np.array(mit_ra)
    mit_dec=np.array(mit_dec)
    mit_sector=np.array(mit_sector)

    return (mit_tid,mit_sector,mit_ra,mit_dec)
#mit_tid,mit_sector,mit_ra,mit_dec = get_mit_tid_ra_dec()
#print len(np.unique(mit_tid))
#print "S 1&2 unique:",len(np.unique(mit_tid[(mit_sector==1) | (mit_sector==2)]))
#print "S 3&4 unique:",len(np.unique(mit_tid[(mit_sector==3) | (mit_sector==4)]))
#print "S 5&6 unique:",len(np.unique(mit_tid[(mit_sector==5) | (mit_sector==6)]))
#exit()
def get_mann_YMG():

    ymg_tid=[]
    with open("YMG_targets.txt","r") as YMG_FILE:
        for lines in YMG_FILE:
            #print int(lines.split(",")[0])
            ymg_tid.append(int(lines.split(",")[0]))
    ymg_tid=np.array(ymg_tid)

    return ymg_tid

def gunter_TESS_indiv_flares():

    # # tic_id,sector,outburst,flare,tpeak,tpeak_ll,tpeak_ul,ampl,ampl_ll,ampl_ul,fwhm,fwhm_ll,fwhm_ul,duration,duration_ll,duration_ul,bol_energy,bol_energy_ll,bol_energy_ul,M_CME,M_CME_ll,M_CME_ul,tessmag,teff,radius,logg,type,tess_rot,kelt_rot,rot,FFD_alpha,FFD_beta,preb_chem,ozone_depl_cons,ozone_depl_perm

    tic_id=[] #0
    sector=[] #1
    outburst=[] #2
    flare=[] #3
    tpeak=[] #4
    tpeak_ll=[] #5
    tpeak_ul=[] #6
    ampl=[] #7
    ampl_ll=[] #8
    ampl_ul=[] #9
    fwhm=[] #10
    fwhm_ll=[] #11
    fwhm_ul=[] #12
    duration=[] #13
    duration_ll=[] #14
    duration_ul=[] #15
    bol_energy=[] #16
    bol_energy_ll=[] #17
    bol_energy_ul=[] #18
    M_CME=[] #19
    M_CME_ll=[] #20
    M_CME_ul=[] #21
    tessmag=[] #22
    teff=[] #23
    radius=[] #24
    logg=[] #25
    sptype=[] #26
    tess_rot=[] #27
    kelt_rot=[] #28
    rot=[] #29
    FFD_alpha=[] #30
    FFD_beta=[] #31
    preb_chem=[] #32
    ozone_depl_cons=[] #33
    ozone_depl_perm=[] #34

    with open("publication_catalog_per_flare_rdx.csv","r") as GUNTER_INFILE:
        next(GUNTER_INFILE)
        for lines in GUNTER_INFILE:
            tic_id.append(int(lines.split(",")[0]))
            sector.append(int(lines.split(",")[1])) #1
            outburst.append(int(lines.split(",")[2])) #2
            flare.append(int(lines.split(",")[3])) #3
            tpeak.append(float(lines.split(",")[4])) #4
            tpeak_ll.append(float(lines.split(",")[5])) #5
            tpeak_ul.append(float(lines.split(",")[6])) #6
            ampl.append(float(lines.split(",")[7])) #7
            ampl_ll.append(float(lines.split(",")[8])) #8
            ampl_ul.append(float(lines.split(",")[9])) #9
            fwhm.append(float(lines.split(",")[10])) #10
            fwhm_ll.append(float(lines.split(",")[11])) #11
            fwhm_ul.append(float(lines.split(",")[12])) #12
            duration.append(float(lines.split(",")[13])) #13
            duration_ll.append(float(lines.split(",")[14])) #14
            duration_ul.append(float(lines.split(",")[15])) #15
            bol_energy.append(float(lines.split(",")[16])) #16
            bol_energy_ll.append(float(lines.split(",")[17])) #17
            bol_energy_ul.append(float(lines.split(",")[18])) #18
            M_CME.append(float(lines.split(",")[19])) #19
            M_CME_ll.append(float(lines.split(",")[20])) #20
            M_CME_ul.append(float(lines.split(",")[21])) #21
            tessmag.append(float(lines.split(",")[22])) #22
            teff.append(float(lines.split(",")[23])) #23
            radius.append(float(lines.split(",")[24])) #24
            logg.append(float(lines.split(",")[25])) #25
            sptype.append(str(lines.split(",")[26])) #26
            tess_rot.append(float(lines.split(",")[27])) #27
            kelt_rot.append(float(lines.split(",")[28])) #28
            rot.append(float(lines.split(",")[29])) #29
            FFD_alpha.append(float(lines.split(",")[30])) #30
            FFD_beta.append(float(lines.split(",")[31])) #31
            preb_chem.append(float(lines.split(",")[32])) #32
            ozone_depl_cons.append(float(lines.split(",")[33])) #33
            ozone_depl_perm.append(float(lines.split(",")[34])) #34
    tic_id= np.array(tic_id) #0
    sector= np.array(sector) #1
    outburst= np.array(outburst) #2
    flare= np.array(flare) #3
    tpeak= np.array(tpeak) #4
    tpeak_ll= np.array(tpeak_ll) #5
    tpeak_ul= np.array(tpeak_ul) #6
    ampl= np.array(ampl) #7
    ampl_ll= np.array(ampl_ll) #8
    ampl_ul= np.array(ampl_ul) #9
    fwhm= np.array(fwhm) #10
    fwhm_ll= np.array(fwhm_ll) #11
    fwhm_ul= np.array(fwhm_ul) #12
    duration= np.array(duration) #13
    duration_ll= np.array(duration_ll) #14
    duration_ul= np.array(duration_ul) #15
    bol_energy= np.array(bol_energy) #16
    bol_energy_ll= np.array(bol_energy_ll) #17
    bol_energy_ul= np.array(bol_energy_ul) #18
    M_CME= np.array(M_CME) #19
    M_CME_ll= np.array(M_CME_ll) #20
    M_CME_ul= np.array(M_CME_ul) #21
    tessmag= np.array(tessmag) #22
    teff= np.array(teff) #23
    radius= np.array(radius) #24
    logg= np.array(logg) #25
    sptype= np.array(sptype) #26
    tess_rot= np.array(tess_rot) #27
    kelt_rot= np.array(kelt_rot) #28
    rot= np.array(rot) #29
    FFD_alpha= np.array(FFD_alpha) #30
    FFD_beta= np.array(FFD_beta) #31
    preb_chem= np.array(preb_chem) #32
    ozone_depl_cons= np.array(ozone_depl_cons) #33
    ozone_depl_perm= np.array(ozone_depl_perm) #34
    
    return (tic_id,bol_energy,ampl,rot,FFD_alpha,FFD_beta,sptype,teff,sector)

def get_lcv(targ):

    mjd=[]
    y=[]
    flags=[]
    cam_tot=[]
    #print targ
    
    with open(targ,"r") as TARG_FILE:
        next(TARG_FILE)
        for lines in TARG_FILE:
            if float(lines.split()[2]) > 0.2:
                continue
            if "nan" in lines:
                continue
            flag = float(lines.split()[3].rstrip("\n"))
            if (flag > 0.0):
                continue
            mjd.append(float(lines.split()[0]))
            y.append(float(lines.split()[1]))
            flags.append(flag)
            try:
                cam_tot.append(float(lines.split()[9]))
            except (IndexError):
                cam_tot.append(-1.0)
    mjd=np.array(mjd)
    y=np.array(y)
    y-=np.median(y)
    cam_tot=np.array(cam_tot)
    flags=np.array(flags)
    
    return (mjd, y, flags, cam_tot)

def load_evr_P_Rot():

    tid_rot=[]
    apass_rot=[]
    ra_rot=[]
    dec_rot=[]
    evr_p_rot=[]
    evr_grade=[]
    evr_notes=[]
    with open("p_rot_byeye_notes.csv","r") as EVR_ROT_INFILE:
        next(EVR_ROT_INFILE)
        next(EVR_ROT_INFILE)
        for lines in EVR_ROT_INFILE:
            tid_rot.append(int(lines.split(",")[0]))
            apass_rot.append(int(lines.split(",")[1]))
            ra_rot.append(float(lines.split(",")[2]))
            dec_rot.append(float(lines.split(",")[3]))
            evr_p_rot.append(float(lines.split(",")[4]))
            evr_grade.append(lines.split(",")[5])
    tid_rot=np.array(tid_rot)
    apass_rot=np.array(apass_rot)
    ra_rot=np.array(ra_rot)
    dec_rot=np.array(dec_rot)
    evr_p_rot=np.array(evr_p_rot)
    evr_grade=np.array(evr_grade)

    return (tid_rot,apass_rot,ra_rot,dec_rot,evr_p_rot,evr_grade)

def read_table_one(table_name):

    tid=[]
    apassid=[]
    ra=[]
    dec=[]
    M_g=[]
    SpT=[]
    Q_0=[]
    gmags=[]
    TESS_mags=[]
    distances=[]
    peak_flux=[]
    contrast=[]
    ED=[]
    log_energies=[]
    event_start=[]
    event_time=[]
    event_stop=[]
    FWHM=[]
    impulsiveness=[]
    signif=[]

    with open(table_name,"r") as TABLE_1_FILE:
        next(TABLE_1_FILE)
        for lines in TABLE_1_FILE:
            tid.append(int(lines.split(",")[0]))
            apassid.append(int(lines.split(",")[1]))
            ra.append(float(lines.split(",")[2]))
            dec.append(float(lines.split(",")[3]))
            M_g.append(float(lines.split(",")[4]))
            SpT.append(str(lines.split(",")[5]))
            Q_0.append(float(lines.split(",")[6]))
            gmags.append(float(lines.split(",")[7]))
            TESS_mags.append(float(lines.split(",")[8]))
            distances.append(float(lines.split(",")[9]))
            peak_flux.append(float(lines.split(",")[10]))
            contrast.append(float(lines.split(",")[11]))
            ED.append(float(lines.split(",")[12]))
            log_energies.append(float(lines.split(",")[13]))
            event_start.append(float(lines.split(",")[14]))
            event_time.append(float(lines.split(",")[15]))
            event_stop.append(float(lines.split(",")[16]))
            FWHM.append(float(lines.split(",")[17]))
            impulsiveness.append(float(lines.split(",")[18]))
            signif.append(float(lines.split(",")[19]))

    tid=np.array(tid)
    apassid=np.array(apassid)
    ra=np.array(ra)
    dec=np.array(dec)
    M_g=np.array(M_g)
    SpT=np.array(SpT)
    Q_0=np.array(Q_0)
    gmags=np.array(gmags)
    TESS_mags=np.array(TESS_mags)
    distances=np.array(distances)
    peak_flux=np.array(peak_flux)
    contrast=np.array(contrast)
    ED=np.array(ED)
    log_energies=np.array(log_energies)
    event_start=np.array(event_start)
    event_time=np.array(event_time)
    event_stop=np.array(event_stop)
    FWHM=np.array(FWHM)
    impulsiveness=np.array(impulsiveness)
    signif=np.array(signif)
            
    return (tid, apassid, ra, dec, M_g, SpT, Q_0, gmags, TESS_mags, distances, peak_flux, contrast, ED, log_energies, event_start, event_time, event_stop, FWHM, impulsiveness, signif)

def read_table_two(table_name):
    
    tid_TII=[]
    apassid_TII=[]
    ra_TII=[]
    dec_TII=[]
    M_g_TII=[]
    SpT_TII=[]
    N_flares_TII=[]
    obs_time_TII=[]
    EVR_alpha_TII=[]
    EVR_alpha_err_low_TII=[]
    EVR_alpha_err_high_TII=[]
    EVR_beta_TII=[]
    EVR_beta_err_low_TII=[]
    EVR_beta_err_high_TII=[]
    superflares_TII=[]
    superflares_err_low_TII=[]
    superflares_err_high_TII=[]
    mean_log_E_TII=[]
    max_log_E_TII=[]
    mean_contrast_TII=[]
    max_contrast_TII=[]
    P_rot_TII=[]
    g_mags_TII=[]
    TESS_mags_TII=[]

    with open(table_name,"r") as TABLE_2_FILE:
        next(TABLE_2_FILE)
        for lines in TABLE_2_FILE:
            tid_TII.append(int(lines.split(",")[0]))
            apassid_TII.append(int(lines.split(",")[1]))
            ra_TII.append(float(lines.split(",")[2]))
            dec_TII.append(float(lines.split(",")[3]))
            M_g_TII.append(float(lines.split(",")[4]))
            SpT_TII.append(str(lines.split(",")[5]))
            N_flares_TII.append(float(lines.split(",")[6]))
            obs_time_TII.append(float(lines.split(",")[7]))
            EVR_alpha_TII.append(float(lines.split(",")[8]))
            EVR_alpha_err_low_TII.append(float(lines.split(",")[9]))
            EVR_alpha_err_high_TII.append(float(lines.split(",")[10]))
            EVR_beta_TII.append(float(lines.split(",")[11]))
            EVR_beta_err_low_TII.append(float(lines.split(",")[12]))
            EVR_beta_err_high_TII.append(float(lines.split(",")[13]))
            superflares_TII.append(float(lines.split(",")[14]))
            superflares_err_low_TII.append(float(lines.split(",")[15]))
            superflares_err_high_TII.append(float(lines.split(",")[16]))
            mean_log_E_TII.append(float(lines.split(",")[17]))
            max_log_E_TII.append(float(lines.split(",")[18]))
            mean_contrast_TII.append(float(lines.split(",")[19]))
            max_contrast_TII.append(float(lines.split(",")[20]))
            P_rot_TII.append(float(lines.split(",")[21]))
            g_mags_TII.append(float(lines.split(",")[22]))
            TESS_mags_TII.append(float(lines.split(",")[23]))
    
    tid_TII= np.array(tid_TII)
    apassid_TII= np.array(apassid_TII)
    ra_TII= np.array(ra_TII)
    dec_TII= np.array(dec_TII)
    M_g_TII= np.array(M_g_TII)
    SpT_TII= np.array(SpT_TII)
    N_flares_TII= np.array(N_flares_TII)
    obs_time_TII= np.array(obs_time_TII)
    EVR_alpha_TII= np.array(EVR_alpha_TII)
    EVR_alpha_err_low_TII= np.array(EVR_alpha_err_low_TII)
    EVR_alpha_err_high_TII= np.array(EVR_alpha_err_high_TII)
    EVR_beta_TII= np.array(EVR_beta_TII)
    EVR_beta_err_low_TII= np.array(EVR_beta_err_low_TII)
    EVR_beta_err_high_TII= np.array(EVR_beta_err_high_TII)
    superflares_TII= np.array(superflares_TII)
    superflares_err_low_TII= np.array(superflares_err_low_TII)
    superflares_err_high_TII= np.array(superflares_err_high_TII)
    mean_log_E_TII= np.array(mean_log_E_TII)
    max_log_E_TII= np.array(max_log_E_TII)
    mean_contrast_TII= np.array(mean_contrast_TII)
    max_contrast_TII= np.array(max_contrast_TII)
    P_rot_TII= np.array(P_rot_TII)
    g_mags_TII= np.array(g_mags_TII)
    TESS_mags_TII= np.array(TESS_mags_TII)
            
    return (tid_TII,apassid_TII,ra_TII,dec_TII,M_g_TII,SpT_TII,N_flares_TII,obs_time_TII,EVR_alpha_TII,EVR_alpha_err_low_TII,EVR_alpha_err_high_TII,EVR_beta_TII,EVR_beta_err_low_TII,EVR_beta_err_high_TII,superflares_TII,superflares_err_low_TII,superflares_err_high_TII,mean_log_E_TII,max_log_E_TII,mean_contrast_TII,max_contrast_TII,P_rot_TII,g_mags_TII,TESS_mags_TII)
