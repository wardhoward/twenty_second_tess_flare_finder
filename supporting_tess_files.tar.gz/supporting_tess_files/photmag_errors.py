import numpy as np
print "\n"

##########################################
"""
gmag_1 = 11.592 #TIC-294750180
e_gmag_1 = 0.032 #TIC-294750180
gmag_2 = 13.743 #TIC-294750180
e_gmag_2 = 0.105 #TIC-294750180

Tmag_1 = 9.2841 #TIC-294750180
e_Tmag_1 = 0.006 #TIC-294750180
Tmag_2 = 10.2973 #TIC-294750180 HD 270712 A and B are about 2 arcsec apart in ATLAS and in CTL and SIMBAD
e_Tmag_2 = 0.0072 #TIC-294750180
"""
##########################################
"""
gmag_1 =  0.0 #TIC-5796048
e_gmag_1 = 0.0 #TIC-5796048
gmag_2 = 0.0 #TIC-5796048
e_gmag_2 = 0.0 #TIC-5796048

Tmag_1 = 10.8081 #TIC-5796048 #40.4257, 0.0739 pc
e_Tmag_1 = 0.0063 #TIC-5796048
Tmag_2 = 10.623 #TIC-5796048
e_Tmag_2 = 0.056 #TIC-5796048
"""
##########################################
"""
gmag_1 =  0.0 #TIC-206327797
e_gmag_1 = 0.0 #TIC-206327797
gmag_2 = 0.0 #TIC-206327797
e_gmag_2 = 0.0 #TIC-206327797

Tmag_1 = 8.6192 #TIC-206327797 #dist err good
e_Tmag_1 = 0.006 #TIC-206327797
Tmag_2 = 9.7389 #TIC-206327797
e_Tmag_2 = 0.00998 #TIC-206327797
"""
##########################################
"""
gmag_1 =  11.674 #TIC-220433364 11.0872 0.0047 pc, 11.0923 0.0038 pc now uodated and good
e_gmag_1 = 0.024 #TIC-220433364
gmag_2 = 12.929 #TIC-220433364
e_gmag_2 = 0.032 #TIC-220433364

Tmag_1 = 8.7057 #TIC-220433364
e_Tmag_1 = 0.00752606 #TIC-220433364
Tmag_2 = 9.42788 #TIC-220433364
e_Tmag_2 = 0.00905 #TIC-220433364
"""
##########################################
"""
gmag_1 =  10.289 #TIC-392756613
e_gmag_1 = 0.09 #TIC-392756613
gmag_2 = 12.750 #TIC-392756613
e_gmag_2 = 0.013 #TIC-392756613

Tmag_1 = 8.1214 #TIC-392756613 16.52532 0.632154, 16.5246 pm 0.0923 good
e_Tmag_1 = 0.0088 #TIC-392756613
Tmag_2 = 7.727 #TIC-392756613
e_Tmag_2 = 0.033 #TIC-392756613
"""
##########################################
"""
gmag_1 =  11.257 #TIC-142086812
e_gmag_1 = 0.09 #TIC-142086812
gmag_2 = 12.163 #TIC-142086812
e_gmag_2 = 0.011 #TIC-142086812

Tmag_1 = 13.481 #TIC-142086812 8.83786 pm 0.002135 pc, n/a
e_Tmag_1 = 1.0 #TIC-142086812
Tmag_2 = 8.20253 #TIC-142086812
e_Tmag_2 = 0.007706 #TIC-142086812
"""
##########################################

gmag_1 = 10.913 #TIC-441398770
e_gmag_1 = 0.021 #TIC-441398770
gmag_2 = 10.946 #TIC-441398770
e_gmag_2 = 0.031 #TIC-441398770

Tmag_1 = 7.396 #TIC-441398770
e_Tmag_1 = 0.04 #TIC-441398770
Tmag_2 = 8.3532 #TIC-441398770 #take the 8 one out- part of another binary
e_Tmag_2 = 0.0075 #TIC-441398770

##########################################
"""
gmag_1 = #TIC-192543856
e_gmag_1 = #TIC-192543856
gmag_2 = #TIC-192543856
e_gmag_2 = #TIC-192543856

Tmag_1 = #TIC-192543856
e_Tmag_1 = #TIC-192543856
Tmag_2 = #TIC-192543856
e_Tmag_2 = #TIC-192543856
"""
##########################################
##########################################
##########################################

# g' mag and errors
x1 = 10.0**(-0.4*gmag_1)
x2 = 10.0**(-0.4*gmag_2)
central_val = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(gmag_1+e_gmag_1))
x2 = 10.0**(-0.4*(gmag_2+e_gmag_2))
other_val1 = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(gmag_1-e_gmag_1))
x2 = 10.0**(-0.4*(gmag_2-e_gmag_2))
other_val2 = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(gmag_1+e_gmag_1))
x2 = 10.0**(-0.4*(gmag_2-e_gmag_2))
other_val3 = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(gmag_1-e_gmag_1))
x2 = 10.0**(-0.4*(gmag_2+e_gmag_2))
other_val4 = -2.5*np.log10(x1+x2)

other_val_array = np.array([other_val1, other_val2, other_val3, other_val4])
err_array = np.array([np.round(central_val-np.min(other_val_array),3),np.round(np.max(other_val_array)-central_val,3)])

print "g=",np.round(central_val,3), np.max(err_array)

#T mag and errors
# T = 9.2841,0.006
# T = 10.2973,0.0072

x1 = 10.0**(-0.4*Tmag_1)
x2 = 10.0**(-0.4*Tmag_2)
central_val = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(Tmag_1+e_Tmag_1))
x2 = 10.0**(-0.4*(Tmag_2+e_Tmag_2))
other_val1 = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(Tmag_1-e_Tmag_1))
x2 = 10.0**(-0.4*(Tmag_2-e_Tmag_2))
other_val2 = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(Tmag_1+e_Tmag_1))
x2 = 10.0**(-0.4*(Tmag_2-e_Tmag_2))
other_val3 = -2.5*np.log10(x1+x2)

x1 = 10.0**(-0.4*(Tmag_1-e_Tmag_1))
x2 = 10.0**(-0.4*(Tmag_2+e_Tmag_2))
other_val4 = -2.5*np.log10(x1+x2)

other_val_array = np.array([other_val1, other_val2, other_val3, other_val4])
err_array = np.array([np.round(central_val-np.min(other_val_array),3),np.round(np.max(other_val_array)-central_val,3)])

print "T=",np.round(central_val,3), np.max(err_array)
