from astropy.stats import LombScargle
from astropy.io import fits
from scipy.optimize import leastsq
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import sigmaclip
import scipy.signal
from scipy.interpolate import interp1d
import glob
import copy
import os
from paper_data_read_functions import read_table_two as read_table_two
print "\n"

def get_lcv(targ):

    mjd=[]
    y=[]
    flags=[]
    cam_tot=[]
    #print targ
    
    with open(targ,"r") as TARG_FILE:
        next(TARG_FILE)
        for lines in TARG_FILE:
            if float(lines.split()[2]) > 0.2:
                continue
            if "nan" in lines:
                continue
            flag = float(lines.split()[3].rstrip("\n"))
            if (flag > 0.0):
                continue
            mjd.append(float(lines.split()[0]))
            y.append(float(lines.split()[1]))
            flags.append(flag)
            try:
                cam_tot.append(float(lines.split()[9]))
            except (IndexError):
                cam_tot.append(-1.0)
    mjd=np.array(mjd)
    y=np.array(y)
    y-=np.median(y)
    cam_tot=np.array(cam_tot)
    flags=np.array(flags)
    
    return (mjd, y, flags, cam_tot)

def fast_pre_whiten_blur(epochs,mags,white_cutoff):
    smoothed_vals=[]
    for i in np.arange(epochs.shape[0]):
        gauss = np.exp(-0.5*(((epochs[i]*np.ones(epochs.shape[0])-epochs)/white_cutoff)**2.0))
        epoch_tot = np.sum(gauss*mags)    
        epoch_weight = np.sum(gauss) #weight further away points more heavily

        smoothed_vals.append(epoch_tot/(1.0*epoch_weight))

    return np.array(smoothed_vals).astype(float)

def get_tess_lcv(fits_table_filename):

    hdulist = fits.open(fits_table_filename)  # open a FITS file
        

    data = hdulist[1].data  # assume the first extension is a table

    # get star time series 
    tess_bjd = hdulist[1].data['TIME']
    sap_flux = hdulist[1].data['SAP_FLUX']
    sap_norm_flux=sap_flux/np.nanmedian(sap_flux)
    
    pdcsap_flux = hdulist[1].data['PDCSAP_FLUX']
    flags = hdulist[1].data['QUALITY']

    # convert to numpy arrays:
    tess_bjd=np.array(tess_bjd)
    sap_norm_flux=np.array(sap_norm_flux)
    flags=np.array(flags)

    temp = np.vstack((tess_bjd,sap_norm_flux,flags)).T
    tess_bjd = np.array([x[0] for x in temp if np.isnan(x[1])==False])
    sap_norm_flux = np.array([x[1] for x in temp if np.isnan(x[1])==False])
    flags = np.array([x[2] for x in temp if np.isnan(x[1])==False])

    #optional smoothing with SG filter:
    #sg_whitened_flux, sg_filter = SG_lcv_smoother(tess_bjd,sap_norm_flux,fits_table_filename)
    
    #return (tess_bjd, sap_norm_flux, flags)
    return (tess_bjd, sap_norm_flux, flags)

def fit_sine(epochs, mags, period):
    # https://stackoverflow.com/
    #questions/16716302/how-do-i-fit-a-sine-curve-to-my-data
    #-with-pylab-and-numpy
    mags-=np.median(mags)
    known_freq = 2.0*np.pi/period

    # Initial guess:
    guess_std=0.1
    guess_phase=0.0 #???
    guess_mean=0.0

    optimize_func = lambda x: x[0]*np.sin(known_freq*epochs+x[1]) + x[2] - mags

    est_std, est_phase, est_mean = leastsq(optimize_func, [guess_std, guess_phase, guess_mean])[0]
    #print est_std, est_phase, est_mean
    
    data_fit = est_std*np.sin(known_freq*epochs + est_phase) + est_mean
    xp = np.linspace(np.nanmin(epochs),np.nanmax(epochs),num=10000)
    sine_func =  est_std*np.sin(known_freq*xp + est_phase) + est_mean
    fit_to_mags = mags - data_fit

    return (fit_to_mags, xp, sine_func)

def compute_1sigma_CI(input_array):

    sorted_input_array = np.sort(input_array)

    low_ind = int(0.16*len(input_array))
    high_ind = int(0.84*len(input_array))

    #low_ind = int(0.05*len(input_array))
    #high_ind = int(0.95*len(input_array))

    bot_val = (sorted_input_array[:low_ind])[-1]
    top_val = (sorted_input_array[high_ind:])[0]

    bot_arr_err = abs(np.nanmedian(input_array) - bot_val)
    top_arr_err = abs(np.nanmedian(input_array) - top_val)

    return (np.nanmedian(input_array), bot_arr_err, top_arr_err)

def clip_outlier_epochs(tess_time_min,tess_conv_mags):

    clip_mags = sigmaclip(tess_conv_mags,3.0,3.0)[0]
    
    temp=np.vstack((tess_time_min,tess_conv_mags)).T
    tess_time_min = np.array([x[0] for x in temp if x[1] in clip_mags])
    tess_conv_mags = np.array([x[1] for x in temp if x[1] in clip_mags])
    
    return (tess_time_min,tess_conv_mags)

#tid_TII,apassid_TII,ra_TII,dec_TII,M_g_TII,SpT_TII,N_flares_TII,obs_time_TII,EVR_alpha_TII,EVR_alpha_err_low_TII,EVR_alpha_err_high_TII,EVR_beta_TII,EVR_beta_err_low_TII,EVR_beta_err_high_TII,superflares_TII,superflares_err_low_TII,superflares_err_high_TII,mean_log_E_TII,max_log_E_TII,mean_contrast_TII,max_contrast_TII,P_rot_TII,g_mags_TII,TESS_mags_TII = read_table_two("EVR_Flare_Stars_Sect1-6_Table_II.csv")

zero_mag = 0.0

tess_lcvs = glob.glob("/home/wshoward/data1/tess/AAS233_figs/evr_flarestars_tess_lcvs/*lc.fits") #load every TESS lcv, select each flare star from this list
tic_id_arr=[]
for i in range(len(tess_lcvs)):
    #print int(tess_lcvs[i].split("-")[2])
    tic_id_arr.append(int(tess_lcvs[i].split("-")[2]))
tic_id_arr=np.array(tic_id_arr)
indices_tic_id = np.arange(len(tic_id_arr))

# make combined-sector lcvs:
tid_TII = np.array([452465896, 123480394, 192543856, 80033631, 11974826, 229152539, 201878287, 168726017, 169148174, 395130640, 52495232, 60764070, 289706625, 55003990, 160329609, 142052876, 419692115, 242189360, 89257479, 47424873, 2760232, 388857263])
ra_TII = np.array([139.272177, 115.049196, 154.557687, 105.028471, 146.491925,28.211614,39.140122,62.23166,291.969527,169.235109,98.873954,138.901789,146.224342, 160.762219,91.217421,97.694244,191.471486,210.962553,312.569085,342.284214, 356.380313,217.393466]) #J2000
dec_TII = np.array([-77.823162, -42.961191, -20.478087, -19.023230, -32.891039,-48.095724,-59.466236,-31.482712,-28.187525,-80.464354,-4.054784,-10.596393,-12.348265, -9.211414,-34.558461,-76.719292,-55.114518,-42.699307,-34.413112,-28.856583, -16.172169,-62.676182])

for i in range(len(tid_TII)):

    #target 47 has a bunch of VERY phased flares with rotation period 
    
    TID = tid_TII[i]
    RA = ra_TII[i]
    DEC = dec_TII[i]

    # get all sectors of TESS light curve
    targ_tic_ids = copy.deepcopy(tic_id_arr)[tic_id_arr==TID]
    targ_inds = indices_tic_id[tic_id_arr==TID]
    
    count=0
    for j in targ_inds:
        #print j,TID,tic_id_arr[j]
        tess_bjd_part, sap_flux_part, flags_part = get_tess_lcv(tess_lcvs[j])
        if count==0:
            tess_bjd=tess_bjd_part
            sap_flux=sap_flux_part
            flags=flags_part
        else:
            tess_bjd=np.concatenate((tess_bjd,tess_bjd_part))
            sap_flux=np.concatenate((sap_flux,sap_flux_part))
            flags=np.concatenate((flags,flags_part))
        count+=1

    tess_bjd = copy.deepcopy(tess_bjd[flags==0.0])
    sap_flux = copy.deepcopy(sap_flux[flags==0.0])
    tess_conv_mags = -2.5*np.log10(sap_flux) + zero_mag
    
    pre_tess_conv_mags = copy.deepcopy(tess_conv_mags)
    
    tess_time_min = tess_bjd
    
    tess_white_mags = fast_pre_whiten_blur(tess_time_min,tess_conv_mags,0.5)
    tess_conv_mags = tess_conv_mags - tess_white_mags

    #best-fit LS power:
    frequency = np.linspace(0.2, 10.0, 2000)
    period_array = 1.0/frequency
    #print np.min(period_array),np.max(period_array)
    #exit()
    power = LombScargle(tess_time_min, tess_conv_mags).power(frequency)
    
    actual_period = np.round(period_array[list(power).index(np.max(power))],6)
    init_p = copy.deepcopy(actual_period)
    
    norm_power = power/np.nanstd(power[np.absolute(period_array-actual_period)>0.5])

    #else condition?
    #if actual_period>5.0:
    #    actual_period=-1.0
    if np.max(norm_power)<100.0:
        actual_period=-1.0

    # do if else where i==X and norm_power>specified cutoffs:
    
    #if (i == 276) and (np.max(norm_power)>50.0):
    #    actual_period = init_p

    #####################################################
    ###           continue processing                 ###
    #####################################################
    
    if actual_period>0.0:
        tess_conv_mags2, xp, sine_func = fit_sine(tess_time_min, tess_conv_mags, actual_period)
    else:
        tess_conv_mags2 = copy.deepcopy(tess_conv_mags)
    
    fig, ax = plt.subplots(figsize=(8,6))
    plt.axis('off')

    ax1 = fig.add_subplot(311)
    ax1.plot(tess_time_min, tess_conv_mags, marker="+",ls="none",color="black")
    if actual_period>0.0:
        ax1.plot(xp, sine_func,ls="-",color="orange")
    plt.xlabel("TBJD",fontsize=12)
    plt.ylabel("TESS-mags",fontsize=12)
    plt.gca().invert_yaxis()
    plt.title("Target "+str(i)+" TID "+str(TID)+" P="+str(actual_period)+" d")
    
    ax2 = fig.add_subplot(312)
    
    #ax2.plot(tess_time_min, pre_tess_conv_mags, marker="+",ls="none",color="grey")
    
    
    ax2.axvspan(0.99*actual_period,1.01*actual_period,facecolor="orange")
    ax2.plot(period_array, norm_power,color="grey")
    #ax2.plot(period_array[np.absolute(period_array-actual_period)>0.5], norm_power[np.absolute(period_array-actual_period)>0.5],color="orange")
    #power[abs(period_array-actual_period)>1.0]
    #leg = plt.legend(facecolor="gainsboro",fontsize=13)
    #leg.get_frame().set_alpha(1.0)
    plt.xlabel("Period [d]",fontsize=12)
    plt.ylabel("Power",fontsize=12)
    #plt.gca().invert_yaxis()
    #plt.ylim(0.15,-0.15)
    #plt.xlim(-0.1,1.1)
    plt.tight_layout()

    ax3 = fig.add_subplot(313)
    ax3.plot(tess_time_min, tess_conv_mags2, marker="+",ls="none",color="black")
    #ax1.plot(xp, sine_func,ls="-",color="orange")
    plt.xlabel("TBJD",fontsize=12)
    plt.ylabel("TESS-mags",fontsize=12)
    plt.gca().invert_yaxis()


    lcv_file = "whtd_star_"+str(i)+"_TIC-"+str(TID)+"_"+str(RA)+"_"+str(DEC)+".csv"
    
    for g in range(len(tess_time_min)):
        info = str(tess_time_min[g])+","+str(tess_conv_mags[g])+","+str(tess_conv_mags2[g])+","+str(actual_period)+"\n"
        with open(lcv_file,"a") as OUTFILE:
            OUTFILE.write(info)
    
    plt.savefig("TESS_lcv_"+str(i)+"TIC-"+str(TID)+".png")
    #plt.show()
    plt.close("all")
    #exit()


print "\ndone!"
