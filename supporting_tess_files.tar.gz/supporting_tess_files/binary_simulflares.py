import glob
import copy
import numpy as np
import os
import astropy.table as tbl
from astropy import time, coordinates as coord, units as u
from paper_data_read_functions import read_table_one
from paper_data_read_functions import read_table_two as read_table_two
from astropy.stats import LombScargle
from astropy.io import fits
from scipy.optimize import leastsq
import matplotlib.pyplot as plt
from scipy.stats import sigmaclip
import scipy.signal
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit
import glob

def linear(x, m, b):
    return m*x + b

def davenport_flare_model(epochs, width, ampl, peak_time):

    if width==0.0 and ampl==0.0 and peak_time==0.0:
        return np.zeros(len(epochs))
    elif ampl<0.000001:
        ampl=100000.0
    else:
        pass
    
    # See Davenport et al 2014, ApJ 797, 2
    t = copy.deepcopy(epochs)
    t/=width
    #assume a gaussian-distribution 1-5mins for risetime, 20-30mins decay
    flare_y = 0.689*np.exp(-1.6*(t-peak_time)) + 0.303*np.exp(-0.2783*(t-peak_time))
    flare_y[(t-peak_time)<0] = 1.0 + (1.941)*(t-peak_time)[(t-peak_time)<0] - 0.175*((t-peak_time)[(t-peak_time)<0]**2) - 2.246*((t-peak_time)[(t-peak_time)<0]**3) - 1.125*((t-peak_time)[(t-peak_time)<0]**4)

    flare_y[flare_y<0.000001]= 0.000001 #set all flare points that would otherwise be negative to val near zero
    flare_y = flare_y*ampl #adjust flare peak amplitude
    #rise; FWHMs not minutes
    return flare_y

def two_peak_dav_flare_model(epochs, width1, ampl1, peak_time1, width2, ampl2, peak_time2):
    flare_y1 = davenport_flare_model(epochs, width1, ampl1, peak_time1)
    flare_y2 = davenport_flare_model(epochs, width2, ampl2, peak_time2)
    flare_y = flare_y1 + flare_y2
    return flare_y

def three_peak_dav_flare_model(epochs, width1, ampl1, peak_time1, width2, ampl2, peak_time2, width3, ampl3, peak_time3):
    flare_y1 = davenport_flare_model(epochs, width1, ampl1, peak_time1)
    flare_y2 = davenport_flare_model(epochs, width2, ampl2, peak_time2)
    flare_y3 = davenport_flare_model(epochs, width3, ampl3, peak_time3)
    flare_y = flare_y1 + flare_y2 + flare_y3
    return flare_y

def four_peak_dav_flare_model(epochs, width1, ampl1, peak_time1, width2, ampl2, peak_time2, width3, ampl3, peak_time3, width4, ampl4, peak_time4):
    flare_y1 = davenport_flare_model(epochs, width1, ampl1, peak_time1)
    flare_y2 = davenport_flare_model(epochs, width2, ampl2, peak_time2)
    flare_y3 = davenport_flare_model(epochs, width3, ampl3, peak_time3)
    flare_y4 = davenport_flare_model(epochs, width3, ampl3, peak_time3)
    flare_y = flare_y1 + flare_y2 + flare_y3 + flare_y4
    return flare_y

def get_ATLAS_gmag():
    atl_TIC=[]
    atl_RA=[]
    atl_Dec=[]
    atl_g=[]
    atl_dg=[]
    atl_r=[]
    atl_dr=[]
    atl_i=[]
    atl_di=[]
    atl_dist=[]
    with open("EVRYFLARE_atlas_xmatch.csv","r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            atl_TIC.append(int(lines.split(",")[0]))
            atl_RA.append(float(lines.split(",")[1]))
            atl_Dec.append(float(lines.split(",")[2]))
            atl_g.append(float(lines.split(",")[3]))
            atl_dg.append(float(lines.split(",")[4]))
            atl_r.append(float(lines.split(",")[5]))
            atl_dr.append(float(lines.split(",")[6]))
            atl_i.append(float(lines.split(",")[7]))
            atl_di.append(float(lines.split(",")[8]))
            atl_dist.append(float(lines.split(",")[9]))
    atl_TIC=np.array(atl_TIC)
    atl_RA=np.array(atl_RA)
    atl_Dec=np.array(atl_Dec)
    atl_g=np.array(atl_g)
    atl_dg=np.array(atl_dg)
    atl_r=np.array(atl_r)
    atl_dr=np.array(atl_dr)
    atl_i=np.array(atl_i)
    atl_di=np.array(atl_di)
    atl_dist=np.array(atl_dist)
    
    return (atl_TIC, atl_g, atl_dg)

def get_tess_lcv(fits_table_filename):

    hdulist = fits.open(fits_table_filename)  # open a FITS file

    data = hdulist[1].data  # assume the first extension is a table

    # get star time series 
    tess_bjd = hdulist[1].data['TIME']
    sap_flux = hdulist[1].data['SAP_FLUX']
    sap_norm_flux=sap_flux/np.nanmedian(sap_flux)
    
    pdcsap_flux = hdulist[1].data['PDCSAP_FLUX']
    flags = hdulist[1].data['QUALITY']

    # convert to numpy arrays:
    tess_bjd=np.array(tess_bjd)
    sap_norm_flux=np.array(sap_norm_flux)
    flags=np.array(flags)

    temp = np.vstack((tess_bjd,sap_norm_flux,flags)).T
    tess_bjd = np.array([x[0] for x in temp if np.isnan(x[1])==False])
    sap_norm_flux = np.array([x[1] for x in temp if np.isnan(x[1])==False])
    flags = np.array([x[2] for x in temp if np.isnan(x[1])==False])

    #optional smoothing with SG filter:
    #sg_whitened_flux, sg_filter = SG_lcv_smoother(tess_bjd,sap_norm_flux,fits_table_filename)
    
    #return (tess_bjd, sap_norm_flux, flags)
    return (tess_bjd, sap_norm_flux, flags)

def build_tess_lightcurve(TID,PATH):
    #print glob.glob(PATH+"*"+str(TID)+"*lc.fits")
    #exit()
    tess_lcvs = glob.glob(PATH+"*lc.fits") #load every TESS lcv, select each flare star from this list
    tic_id_arr=[]
    for i in range(len(tess_lcvs)):
        #print int(tess_lcvs[i].split("-")[2])
        tic_id_arr.append(int(tess_lcvs[i].split("-")[2]))
    tic_id_arr=np.array(tic_id_arr)
    indices_tic_id = np.arange(len(tic_id_arr))
    
    targ_tic_ids = copy.deepcopy(tic_id_arr)[tic_id_arr==TID]
    targ_inds = indices_tic_id[tic_id_arr==TID]
    #print ""

    sector_list=[]
    
    count=0
    for j in targ_inds:
        #print j,TID,tic_id_arr[j]
        #print int(tess_lcvs[j].split("-")[-4].replace("s",""))
        sector_list.append(int(tess_lcvs[j].split("-")[-4].replace("s","")))
        tess_bjd_part, sap_flux_part, flags_part = get_tess_lcv(tess_lcvs[j])
        if count==0:
            tess_bjd=tess_bjd_part
            sap_flux=sap_flux_part
            flags=flags_part
        else:
            tess_bjd=np.concatenate((tess_bjd,tess_bjd_part))
            sap_flux=np.concatenate((sap_flux,sap_flux_part))
            flags=np.concatenate((flags,flags_part))
        count+=1

    tess_bjd = copy.deepcopy(tess_bjd)
    sap_flux = copy.deepcopy(sap_flux)
    first_sector = np.min(sector_list)
    last_sector = np.max(sector_list)

    return (tess_bjd,sap_flux,first_sector,last_sector)

_lambda = np.linspace(1.0, 1500.0, num=1000) # nm
Lambda = copy.deepcopy(_lambda)

def blackbody_spectrum(_lambda, temp):
    __lambda = copy.deepcopy(_lambda)
    __lambda *= (10.0**(-9.0)) # from nm to m
    h = 6.62607004 * 10.0**(-34.0) # Planck's constant m^2 kg / s
    c = 3.0*(10.0**8.0) #m/s
    k_B = 1.38064852 * 10.0**(-23.0) # Boltzmann constant (m^2 kg / s^2 K)
    T = temp #9000.0 # K
    flux = 2.0*h*(c**2.0) / ((__lambda**5.0)*(np.exp(h*c/(__lambda*k_B*T),dtype=np.float128)-1.0))

    return flux

# Green filters:
filt_wavelength=[]
filt_response=[]
with open("./run4/ctio_omega_g.csv","r") as FILTER:
    for lines in FILTER:
        filt_wavelength.append(float(lines.split(",")[0]))
        filt_response.append(0.01*float(lines.split(",")[1].rstrip("\n")))
filt_wavelength=np.array(filt_wavelength)
filt_response=np.array(filt_response)

CCD_wavelength=[]
CCD_response=[]
with open("./run4/ML290050_QE.csv","r") as CCD:
    for lines in CCD:
        CCD_wavelength.append(float(lines.split(",")[0]))
        CCD_response.append(0.01*float(lines.split(",")[1].rstrip("\n")))
CCD_wavelength=np.array(CCD_wavelength)
CCD_response=np.array(CCD_response)

interp_filt=interp1d(filt_wavelength,filt_response,kind="linear",fill_value=0.0,bounds_error=False)
interp_CCD=interp1d(CCD_wavelength,CCD_response,kind="linear",fill_value=0.0,bounds_error=False)

g_response_fn = interp_filt(Lambda)*interp_CCD(Lambda)

#A = np.trapz(g_response_fn,Lambda)
#B = np.trapz(filt_response,filt_wavelength)

in_gband = g_response_fn[g_response_fn > 0.05]
g_response_fn/=np.average(in_gband)

# TESS response function:
TESS_wavelength=[]
TESS_response=[]
with open("./run4/tess-response-function-v1.0.csv","r") as FILTER:
    next(FILTER) #1
    next(FILTER) #2
    next(FILTER) #3
    next(FILTER) #4
    next(FILTER) #5
    next(FILTER) #6
    next(FILTER) #7
    next(FILTER) #8
    next(FILTER) #9
    
    for lines in FILTER:
        TESS_wavelength.append(float(lines.split(",")[0]))
        TESS_response.append(float(lines.split(",")[1].rstrip("\n")))
TESS_wavelength=np.array(TESS_wavelength)
TESS_response=np.absolute(np.array(TESS_response))

interp_TESS = interp1d(TESS_wavelength,TESS_response,kind="linear",fill_value=0.0,bounds_error=False)

TESS_response_fn = interp_TESS(Lambda)

in_Tband = TESS_response_fn[TESS_response_fn > 0.05]
TESS_response_fn/=np.average(in_Tband)

BB_temps = np.linspace(500.0,50000.0,num=4000) # set to 2000 steps!!!

ratios=[]
for i in range(len(BB_temps)):
    flux = blackbody_spectrum(_lambda, BB_temps[i])

    flux_in_g = flux*g_response_fn
    flux_in_T = flux*TESS_response_fn

    area_in_g = np.trapz(flux_in_g, _lambda)
    area_in_T = np.trapz(flux_in_T, _lambda)

    ratios.append(area_in_g/area_in_T)
    #print BB_temps[i],"K"
ratios=np.array(ratios)

ratios[0] = 0.0
ratios[-1]=10.0

#plt.plot(ratios,BB_temps)
#plt.xlabel("Ratio")
#plt.ylabel("Teff")
#plt.show()
#exit()

get_teff = interp1d(ratios, BB_temps, kind="linear")
#exit()

######################################################################

def fast_pre_whiten_blur(epochs,mags,white_cutoff):
    smoothed_vals=[]
    for i in np.arange(epochs.shape[0]):
        gauss = np.exp(-0.5*(((epochs[i]*np.ones(epochs.shape[0])-epochs)/white_cutoff)**2.0))
        epoch_tot = np.sum(gauss*mags)    
        epoch_weight = np.sum(gauss) #weight further away points more heavily

        smoothed_vals.append(epoch_tot/(1.0*epoch_weight))

    return np.array(smoothed_vals).astype(float)

def get_Q0_luminosity(d, inband_mag, bandpass):

    TESS_0 = 4.03*(10.0**(-6.0)) #Sullivan 2015, 4.03 x 10^-6 erg /s cm2
    TESS_0 = TESS_0 * (10.0**(-7.0)) #J/erg, now in J/(s cm^2) or W/cm^2
    TESS_0 = TESS_0 * (10.0**4.0) #cm^2 / m^2, now in W/m^2

    #print TESS_0 #W/m^2
    #print np.log10(TESS_0)


    meters_per_pc = 3.086*(10.0**(16.0))
    #d = 1.3018 #Proxima dist, parsec
    d*=meters_per_pc #parsecs to meters
    d*=100.0 #meters to cm

    mu=0.15 # eff g' in micrometers from Gemini
    g0_flux = 5.41*(10.0**-8.0) # in W/m^2/mu
    watt_to_erg_per_sec = 10.0**7.0 # J/sec to ergs/sec
    meter2_to_cm2 = 10.0**(-4.0) # m^2 / cm^2

    if bandpass == "g-mag":
        g0_flux_erg = g0_flux*mu*watt_to_erg_per_sec*meter2_to_cm2
    elif bandpass == "T-mag":
        g0_flux_erg = TESS_0*watt_to_erg_per_sec*meter2_to_cm2
    else:
        print "No such bandpass",bandpass
        print "Exiting now."
        exit()

    #from apparent mag to stellar flux:
    F_star = g0_flux_erg * 10.0**((inband_mag)/(-2.5))

    Q_0 = 4.0*np.pi*(d**2.0)*F_star #quiesc. flux in g' in erg/s

    return Q_0

def correct_source_brightness(input_ticid):

    if input_ticid==294750180:
        new_g=11.452
        new_dg=0.041
        new_T=8.924
        new_dT=0.006
    
    
    return (new_g, new_dg, new_T, new_dT)

def get_evr_lc(evr_filestring):
    evr_mjd=[]
    evr_gmag=[]
    evr_gmag_err=[]
    evr_snr=[]
    evr_lim_mag=[]
    with open(evr_filestring,"r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            evr_mjd.append(float(lines.split(",")[0]))
            evr_gmag.append(float(lines.split(",")[1]))
            evr_gmag_err.append(float(lines.split(",")[2]))
            evr_snr.append(float(lines.split(",")[3]))
            evr_lim_mag.append(float(lines.split(",")[4].rstrip("\n")))
    evr_mjd=np.array(evr_mjd)
    evr_gmag=np.array(evr_gmag)-np.nanmedian(evr_gmag)
    evr_gmag_err=np.array(evr_gmag_err)
    evr_snr=np.array(evr_snr)
    evr_lim_mag=np.array(evr_lim_mag)
    evr_flags=np.zeros(len(evr_snr))
    evr_flags[evr_snr<10.0] = 1.0

    return (evr_mjd, evr_gmag, evr_gmag_err, evr_flags)

def get_prewh_lcv(targ):
    tbjd=[]
    tmags=[]
    with open(targ,"r") as INFILE:
        for lines in INFILE:
            tbjd.append(float(lines.split(",")[0]))
            tmags.append(float(lines.split(",")[2]))
    tbjd = np.array(tbjd) + 2457000.0 - 2400000.5
    tmags = np.array(tmags)
    
    return (tbjd, tmags)

def load_J2000_coords():

    gi_tic=[]
    gi_ra=[]
    gi_dec=[]
    with open("wshoward_evryflare_tess_gi_prop_c3.csv","r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            gi_tic.append(int(lines.split(",")[0]))
            gi_ra.append(float(lines.split(",")[1]))
            gi_dec.append(float(lines.split(",")[2]))
    gi_tic=np.array(gi_tic).astype(int)
    gi_ra=np.array(gi_ra)
    gi_dec=np.array(gi_dec)
    
    return (gi_tic, gi_ra, gi_dec)

def load_MAST_data():
    ID=[]
    RA=[]
    Dec=[]
    MatchID=[]
    MatchRa=[]
    MatchDEC=[]
    dstArcSec=[]
    gmag=[]
    e_gmag=[]
    Tmag=[]
    e_Tmag=[]
    mass=[]
    e_mass=[]
    d=[]
    e_d=[]
    
    with open("reduced_MAST_Crossmatch_CTL_evryflare_III.csv","r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            ID.append(int(lines.split(",")[0]))
            RA.append(float(lines.split(",")[1]))
            Dec.append(float(lines.split(",")[2]))
            MatchID.append(int(lines.split(",")[3]))
            MatchRa.append(float(lines.split(",")[4]))
            MatchDEC.append(float(lines.split(",")[5]))
            #dstArcSec.append(float(lines.split(",")[6]))
            #gmag.append(float(lines.split(",")[7]))
            #e_gmag.append(float(lines.split(",")[8]))
            Tmag.append(float(lines.split(",")[9]))
            e_Tmag.append(float(lines.split(",")[10]))
            #mass.append(float(lines.split(",")[11]))
            #e_mass.append(float(lines.split(",")[12]))
            d.append(float(lines.split(",")[13]))
            e_d.append(float(lines.split(",")[14]))
    MAST_ID=np.array(ID)
    MAST_RA=np.array(RA)
    MAST_Dec=np.array(Dec)
    MatchID=np.array(MatchID)
    MatchRa=np.array(MatchRa)
    MatchDEC=np.array(MatchDEC)
    #MAST_dstArcSec=np.array(dstArcSec)
    #MAST_gmag=np.array(gmag)
    #MAST_e_gmag=np.array(e_gmag)
    MAST_Tmag=np.array(Tmag)
    MAST_e_Tmag=np.array(e_Tmag)
    #MAST_mass=np.array(mass)
    #MAST_e_mass=np.array(e_mass)
    MAST_d=np.array(d)
    MAST_e_d=np.array(e_d)
    
    return (MatchID, MAST_Tmag, MAST_e_Tmag, MAST_d, MAST_e_d)

def clean_evr_lc(i, evr_mjd_window, evr_fracflux):
    flag_bool = np.zeros(len(evr_mjd_window)).astype(int)
    cp_evr_mjd_window = copy.deepcopy(evr_mjd_window)
    cp_evr_fracflux = copy.deepcopy(evr_fracflux)
    
    if i==50:
        flag_bool[(evr_fracflux>0.3519)&(evr_mjd_window<0.0299)] = 1
        flag_bool[(evr_fracflux>2.3)&(evr_mjd_window>0.1139)] = 1
    elif i==76:
        flag_bool[(evr_mjd_window>0.085)] = 1
    elif i==110:
        flag_bool[(evr_fracflux>0.37)&(evr_mjd_window>0.083)] = 1
    elif i==161:
        flag_bool[(evr_mjd_window<0.01633)] = 1
    elif i==168:
        flag_bool[(evr_fracflux>0.76)] = 1
    elif i==233:
        flag_bool[(evr_mjd_window<0.1014)] = 1
    elif i==300:
        flag_bool[(evr_fracflux>1.313)] = 1
    elif i==500:
        flag_bool[(evr_fracflux<-0.11)] = 1
    elif i==553:
        flag_bool[(evr_fracflux>0.202)] = 1
        flag_bool[(evr_fracflux>0.097)&(evr_mjd_window>0.088)] = 1
    elif i==688: #ratchet offset?
        flag_bool[(evr_mjd_window>0.0784)] = 1
    elif i==729:
        flag_bool[(evr_fracflux>1.444)&(evr_mjd_window<0.0027)] = 1
    pass
        
    return (cp_evr_mjd_window[flag_bool==0], cp_evr_fracflux[flag_bool==0])

def adjust_evr_by_target(i, evr_mjd_window, evr_fracflux):

    i_list = []
    evr_start_list = []
    evr_stop_list = []
    evr_FWHM_start = []
    evr_FWHM_stop = []
    CW_start = []
    CW_stop = []
    with open("good_simulflares.csv","r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            i_list.append(int(lines.split(",")[0]))
            evr_start_list.append(float(lines.split(",")[1]))
            evr_stop_list.append(float(lines.split(",")[2]))
            evr_FWHM_start.append(float(lines.split(",")[3]))
            evr_FWHM_stop.append(float(lines.split(",")[4]))
            CW_start.append(float(lines.split(",")[5]))
            CW_stop.append(float(lines.split(",")[6].rstrip("\n")))
    i_list = np.array(i_list)
    evr_start_list = np.array(evr_start_list)
    evr_stop_list = np.array(evr_stop_list)
    evr_FWHM_start = np.array(evr_FWHM_start)
    evr_FWHM_stop = np.array(evr_FWHM_stop)
    CW_start = np.array(CW_start)
    CW_stop = np.array(CW_stop)

    try:
        ESTART = evr_start_list[i_list==i][0]
        ESTOP = evr_stop_list[i_list==i][0]
        FWHM_START = evr_FWHM_start[i_list==i][0]
        FWHM_STOP = evr_FWHM_stop[i_list==i][0]
        CW_START = CW_start[i_list==i][0]
        CW_STOP = CW_stop[i_list==i][0]
    except (IndexError):
        ESTART = np.min(evr_mjd_window)
        ESTOP = np.max(evr_mjd_window)
        FWHM_START = np.min(evr_mjd_window)
        FWHM_STOP = np.max(evr_mjd_window)
        CW_START =np.min(evr_mjd_window)
        CW_STOP = np.max(evr_mjd_window)
    
    if i==50:
        EMEAN = np.nanmedian(evr_fracflux[(evr_mjd_window<=ESTART)])
    elif i==553:
        EMEAN = np.nanmedian(evr_fracflux[(evr_mjd_window>=ESTOP)])
    else:
        EMEAN = np.nanmedian(evr_fracflux[(evr_mjd_window<=ESTART)|(evr_mjd_window>=ESTOP)])

    evr_fracflux = evr_fracflux - EMEAN
    
    return (evr_mjd_window, evr_fracflux, ESTART, ESTOP, FWHM_START, FWHM_STOP,CW_START,CW_STOP)

def adjust_tess_by_target(i,tess_mjd_window,tess_fracflux,tess_mjd_raw_window,tess_raw_fracflux,NEWSTART,NEWSTOP):
    
    if i==17:
        tess_mjd_window = copy.deepcopy(tess_mjd_raw_window)
        tess_fracflux = copy.deepcopy(tess_raw_fracflux)
    elif i==110:
        tess_mjd_window =tess_mjd_window[3:]
        tess_fracflux = tess_fracflux[3:]
    elif i==233:
        x_vals = copy.deepcopy(tess_mjd_window[(tess_mjd_window<=NEWSTART)|(tess_mjd_window>=(1.05*NEWSTOP))])
        y_vals = copy.deepcopy(tess_fracflux[(tess_mjd_window<=NEWSTART)|(tess_mjd_window>=(1.05*NEWSTOP))])
        popt, pcov = curve_fit(linear, x_vals, y_vals)

        tess_fracflux = tess_fracflux - linear(tess_mjd_window, *popt)
        
    elif i==606:
        tess_mjd_window = tess_mjd_window[tess_fracflux>-0.08555]
        tess_fracflux= tess_fracflux[tess_fracflux>-0.08555]
    elif i==661:
        tess_mjd_window = tess_mjd_window[tess_fracflux>-0.03]
        tess_fracflux= tess_fracflux[tess_fracflux>-0.03]
    else:
        pass
    
    return (tess_mjd_window, tess_fracflux)

def get_JR_revised_spt():
    # JR_tic_id,JR_SpT,updated_T_eff,T_eff_EvryFlare_I,updated_masses=get_JR_revised_spt()
    JR_tic_id=[]
    JR_SpT=[]
    updated_SpT=[]
    updated_T_eff=[]
    T_eff_EvryFlare_I=[]
    updated_masses=[]
    spot_increases=[] #assuming non-0K spots...
    spot_temp=[]
    with open("EvryFlare_II_Table_Jeff_SpT_addendum.csv","r") as INPUT_FILE:
        next(INPUT_FILE)
        for lines in INPUT_FILE:
            JR_tic_id.append(int(lines.split(",")[0]))
            JR_SpT.append(lines.split(",")[1])
            updated_SpT.append(lines.split(",")[2])
            updated_T_eff.append(float(lines.split(",")[3]))
            T_eff_EvryFlare_I.append(float(lines.split(",")[4]))
            updated_masses.append(float(lines.split(",")[5]))
            spot_increases.append(float(lines.split(",")[6]))
            spot_temp.append(float(lines.split(",")[7]))
    JR_tic_id=np.array(JR_tic_id)
    JR_SpT=np.array(JR_SpT)
    updated_SpT=np.array(updated_SpT)
    updated_T_eff=np.array(updated_T_eff)
    T_eff_EvryFlare_I=np.array(T_eff_EvryFlare_I)
    updated_masses=np.array(updated_masses)
    spot_increases=np.array(spot_increases)
    spot_temp=np.array(spot_temp)
    
    return (JR_tic_id,JR_SpT,updated_SpT,updated_T_eff,T_eff_EvryFlare_I,updated_masses,spot_increases,spot_temp)
        

TID=[]
RA=[]
DEC=[]
YEAR=[]
MON=[]
DAY=[]
HR=[]
MIN=[]
SEC=[]
JD=[]
JD_start=[]
JD_stop=[]
GMAG=[]
with open("./run4/dedup_combined_K7_M5_vetted_tess_flares.csv","r") as INFILE:
    for lines in INFILE:
        TID.append(int(lines.split(",")[0]))
        RA.append(float(lines.split(",")[1]))
        DEC.append(float(lines.split(",")[2]))
        YEAR.append(int(lines.split(",")[3]))
        MON.append(int(lines.split(",")[4]))
        DAY.append(int(lines.split(",")[5]))
        HR.append(int(lines.split(",")[6]))
        MIN.append(int(lines.split(",")[7]))
        SEC.append(float(lines.split(",")[8]))
        JD.append(float(lines.split(",")[9]))
        JD_start.append(float(lines.split(",")[10]))
        JD_stop.append(float(lines.split(",")[11]))
        GMAG.append(float(lines.split(",")[12]))
TID = np.array(TID)
RA = np.array(RA)
DEC = np.array(DEC)
YEAR = np.array(YEAR)
MON = np.array(MON)
DAY = np.array(DAY)
HR = np.array(HR)
MIN = np.array(MIN)
SEC = np.array(SEC)
MJD = np.array(JD) - 2400000.5
MJD_start = np.array(JD_start) - 2400000.5
MJD_stop = np.array(JD_stop) - 2400000.5
GMAG = np.array(GMAG)

print YEAR[TID==388857263],MON[TID==388857263],DAY[TID==388857263], HR[TID==388857263], MIN[TID==388857263]
print np.arange(len(TID))[TID==388857263]
#exit()

# read in EVR flare data tables
tid_TI, apassid_TI, ra_TI, dec_TI, M_g_TI, SpT_TI, Q_0_TI, gmags_TI, TESS_mags_TI, distances_TI, peak_flux_TI, contrast_TI, ED_TI, EVR_log_energies_TI, event_start_TI, event_time_TI, event_stop_TI, FWHM_TI, impulsiveness_TI, signif_TI = read_table_one("./run4/EVR_Flares_Sect1-6_Table_I.csv")

tid_TII,apassid_TII,ra_TII,dec_TII,M_g_TII,SpT_TII,N_flares_TII,obs_time_TII,EVR_alpha_TII,EVR_alpha_err_low_TII,EVR_alpha_err_high_TII,EVR_beta_TII,EVR_beta_err_low_TII,EVR_beta_err_high_TII,superflares_TII,superflares_err_low_TII,superflares_err_high_TII,mean_log_E_TII,max_log_E_TII,mean_contrast_TII,max_contrast_TII,P_rot_TII,g_mags_TII,TESS_mags_TII = read_table_two("./run4/postref_EVR_Flare_Stars_Sect1-6_Table_II.csv")

JR_tic_id,JR_SpT,updated_SpT,updated_T_eff,T_eff_EvryFlare_I,updated_masses,spot_increases,spot_temp=get_JR_revised_spt()

atl_TIC, atl_g, atl_dg = get_ATLAS_gmag()

gi_tic, gi_ra, gi_dec = load_J2000_coords()

MatchID, MAST_Tmag, MAST_e_Tmag, MAST_d, MAST_e_d = load_MAST_data()

# special photometry:
list_of_dirs2 = glob.glob("./special/special_TIC*csv")
S_valid_TID_YMD=[]
for i in range(len(list_of_dirs2)):
    IDstr = list_of_dirs2[i].replace("./special/special_TIC-","").replace("_lc.csv","")
    S_valid_TID_YMD.append(IDstr)
S_valid_TID_YMD=np.array(S_valid_TID_YMD).astype(str)

#efte photometry:
list_of_dirs2 = glob.glob("./run4/TIC*csv")
N_valid_TID_YMD=[]
for i in range(len(list_of_dirs2)):
    IDstr = list_of_dirs2[i].replace("./run4/TIC-","").replace("_lc.csv","")
    N_valid_TID_YMD.append(IDstr)
N_valid_TID_YMD=np.array(N_valid_TID_YMD).astype(str)

#already_found_short = [32, 43, 47, 50, 70, 76, 101, 102, 120, 161, 167, 168, 169, 175, 178, 233, 290, 300, 346, 377, 379, 445, 482, 500, 553, 606, 608, 661, 674, 688, 692, 719, 735, 769]

#newly_found_short = [0, 4, 10, 16, 17, 19, 26, 110, 134, 157, 721]

already_found = [25, 32, 43, 47, 50, 70, 71, 76, 101, 102, 107, 120, 161, 167, 168, 169, 175, 178, 182, 210, 233, 290, 300, 340, 346, 363, 377, 379, 445, 482, 500, 553, 606, 608, 661, 674, 688, 692, 719, 729, 735, 769, 762]

newly_found =[0, 4, 10, 16, 17, 19, 26, 110, 134, 152, 157, 721, 757, 762, 777, 779, 788, 791, 792, 793, 794]

proxima = [757, 762, 769, 777, 779, 788, 791, 792, 793, 794]

print len(already_found)+len(newly_found),"simultaneous flares total.\n"
#exit()

fl_temperatures=[]
for i in range(len(TID)):

    if i!=777: #25
        continue
    
    # which starts and stops do we really want to use? EVRY or TESS?
    
    #if (i not in already_found) and (i not in newly_found):
    #    continue

    if i in already_found:
        
        TID_ACTUAL_YMD = str(TID[i])+"_"+str(YEAR[i])+"-"+str(MON[i])+"-"+str(DAY[i])
        print TID_ACTUAL_YMD+" "+str(HR[i])+" "+str(MIN[i])
        evr_filestring = glob.glob("./run4/TIC-"+str(TID_ACTUAL_YMD)+"*.csv")[0]
    
        evr_mjd, evr_gmag, evr_gmag_err, evr_flags = get_evr_lc(evr_filestring)
        
    if i in newly_found:
        if len(str(MON[i]))<2:
            MONSTR = "0"+str(MON[i])
        else:
            MONSTR = str(MON[i])
        if len(str(DAY[i]))<2:
            DAYSTR = "0"+str(DAY[i])
        else:
            DAYSTR = str(DAY[i])
        TID_ACTUAL_YMD = str(TID[i])+"_"+str(YEAR[i])+str(MONSTR)+str(DAYSTR)

        print TID_ACTUAL_YMD+" "+str(HR[i])+" "+str(MIN[i])
        evr_filestring = glob.glob("./special/special_TIC-"+str(TID_ACTUAL_YMD)+"*.csv")[0]

        evr_mjd=[]
        evr_gmag=[]
        with open(evr_filestring,"r") as INFILE:
            for lines in INFILE:
                evr_mjd.append(float(lines.split(",")[0]))
                evr_gmag.append(float(lines.split(",")[1]))
        evr_mjd = np.array(evr_mjd)
        evr_gmag2 = copy.deepcopy(np.array(evr_gmag))
        
        evr_gmag = np.array(evr_gmag)-np.nanmedian(sigmaclip(evr_gmag,3.0,3.0)[0])
        if np.all(np.isnan(evr_gmag))==True:
            evr_gmag = evr_gmag2-np.nanmedian(evr_gmag2)
        evr_gmag_err = 0.1*np.absolute(evr_gmag-np.median(evr_gmag))

    #####    INSERT FLARE PARAMS    #####
    START=MJD_start[i]
    STOP=MJD_stop[i]

    WIND_START = START - 0.055
    WIND_STOP = STOP + 0.025

    lcv_TID = glob.glob("./run4/whtd_star/whtd_star*_TIC-"+str(TID[i])+"_*.csv")[0]
    
    tbjd, tmags = get_prewh_lcv(lcv_TID)

    PATH2 = "/home/wshoward/data1/tess/AAS233_figs/evr_flarestars_tess_lcvs/"
    
    tess_bjd2, sap_flux, first_sector, last_sector = \
            build_tess_lightcurve(TID[i], PATH2)
    tess_conv_mags = -2.5*np.log10(sap_flux)
    
    tess_bjd2 = tess_bjd2 + 2457000.0 - 2400000.5

    old_inflare_tbjd = tbjd[(tbjd>START) & (tbjd<STOP)]
    old_inflare_tmags = tmags[(tbjd>START) & (tbjd<STOP)]

    inwindow_tbjd = tbjd[(tbjd>WIND_START) & (tbjd<WIND_STOP)]
    inwindow_tmags = tmags[(tbjd>WIND_START) & (tbjd<WIND_STOP)]

    inwindow_tess_conv_mags = tess_conv_mags[(tess_bjd2>WIND_START) & (tess_bjd2<WIND_STOP)]
    inwindow_tess_bjd2 = tess_bjd2[(tess_bjd2>WIND_START) & (tess_bjd2<WIND_STOP)]

    evr_mjd_window =evr_mjd[(evr_mjd>WIND_START)&(evr_mjd<WIND_STOP)]-np.min(inwindow_tbjd)   
    
    evr_fracflux = (-1.0) + 2.512**(-evr_gmag[(evr_mjd>WIND_START)&(evr_mjd<WIND_STOP)])

    evr_mjd_window, evr_fracflux = clean_evr_lc(i, evr_mjd_window, evr_fracflux)

    evr_mjd_window_insec = 24.0*3600.0*evr_mjd_window #in seconds

    NEWSTART = START - np.min(inwindow_tbjd)
    NEWSTOP = STOP - np.min(inwindow_tbjd)
    
    tess_mjd_window = inwindow_tbjd-np.min(inwindow_tbjd)
    tess_fracflux = (-1.0) + 2.512**(-inwindow_tmags)
    tess_mjd_raw_window =  inwindow_tess_bjd2 - np.nanmin(inwindow_tbjd)
    tess_raw_fracflux = (-1.0) + 2.512**(-inwindow_tess_conv_mags)
    
    tess_mjd_window, tess_fracflux = adjust_tess_by_target(i,tess_mjd_window,tess_fracflux,tess_mjd_raw_window,tess_raw_fracflux,NEWSTART,NEWSTOP)


    inflare_tbjd = copy.deepcopy(tess_mjd_window[(tess_mjd_window>=NEWSTART)&(tess_mjd_window<=NEWSTOP)])
    inflare_fflux = copy.deepcopy(tess_fracflux[(tess_mjd_window>=NEWSTART)&(tess_mjd_window<=NEWSTOP)])
    
    tess_mjd_window_insec = 24.0*3600.0*tess_mjd_window #in seconds

    evr_mjd_window,evr_fracflux,ESTART,ESTOP,FWHM_start_val,FWHM_stop_val,CW_START,CW_STOP = \
            adjust_evr_by_target(i, evr_mjd_window, evr_fracflux)

    x_tess = tess_mjd_window[(tess_mjd_window>=CW_START)&(tess_mjd_window<=CW_STOP)]
    y_tess = tess_fracflux[(tess_mjd_window>=CW_START)&(tess_mjd_window<=CW_STOP)]
    x_evry = evr_mjd_window[(evr_mjd_window>=CW_START)&(evr_mjd_window<=CW_STOP)]
    y_evry = evr_fracflux[(evr_mjd_window>=CW_START)&(evr_mjd_window<=CW_STOP)]

    cut_index = np.array([v for v in np.arange(len(y_evry)) if np.isnan(y_evry[v])==False]).astype(int)

    y_evry = y_evry[cut_index]
    x_evry = x_evry[cut_index]

    index = np.argsort(x_evry)
    y_evry = y_evry[index]
    x_evry = x_evry[index]

    interp_y_evry = interp1d(x_evry,y_evry,fill_value=0.00001,bounds_error=False,kind="linear")
    y_evry_regrid = interp_y_evry(x_tess)

    evi = np.argsort(x_evry) #evryscope x-index
    
    fig, ax = plt.subplots(figsize=(7,5))
    plt.axis('off')

    plt.title(str(i)+" TIC "+TID_ACTUAL_YMD.replace("_","  UT: ")+" "+str(HR[i])+":"+str(MIN[i]))
    
    ax1 = fig.add_subplot(111)
    
    ax1.plot(x_evry, y_evry, marker="o",ls="none", color="cornflowerblue")
    plt.ylabel("$\Delta$F/F in $g^{\prime}$-band",color="royalblue",fontsize=14)
    plt.yticks(color="royalblue",fontsize=12)
    #plt.xticks(color="black",fontsize=12)
    plt.xlabel("Elapsed Time [hr]",fontsize=14)
    
    ax3 = ax1.twinx()
    ax3.plot(x_tess, y_tess, marker="o",ls="none", color="firebrick")
    plt.yticks(color="firebrick",fontsize=12)
    plt.ylabel("$\Delta$F/F in TESS band",color="firebrick",fontsize=14)
    plt.tight_layout()
    #plt.savefig("/home/wshoward/Desktop/repeating_flare_"+str(TID_ACTUAL_YMD)+".png")
    plt.show()
    plt.close("all")
    
    #with open("sorted_datetimes_v1.csv","a") as OUTF:
    #    OUTF.write(str(i)+" TIC "+TID_ACTUAL_YMD.replace("_","  UT: ")+" "+str(HR[i])+":"+str(MIN[i])+"\n")
    continue
    #def ampl_only_flare_model1(epochs, ampl):
    #    return davenport_flare_model(epochs, popt_tess_s1[0], ampl, popt_tess_s1[2])

    #continue
    #exit()
    
    fig, ax = plt.subplots(figsize=(8,5))
    plt.axis('off')

    ax1 = fig.add_subplot(211)
    plt.title(str(i)+" "+str(TID[i]))

    ax1.axhline(0.5*np.nanmax(evr_fracflux),color="darkorange")

    #ax1.axvline(fl_start_val,color="green")
    #ax1.axvline(fl_stop_val,color="green")
    ax1.axvline(FWHM_start_val,color="salmon")
    ax1.axvline(FWHM_stop_val,color="salmon")

    FWHM = (FWHM_stop_val-FWHM_start_val)*24.0*60.0 #in mins
    evr_peakFF = np.round(np.nanmax(evr_fracflux[(evr_mjd_window>FWHM_start_val)&(evr_mjd_window<FWHM_stop_val)]),2)
    tess_peakFF = np.round(np.nanmax(tess_fracflux[(tess_mjd_window>FWHM_start_val)&(tess_mjd_window<FWHM_stop_val)]),2)

    impulse = np.round(evr_peakFF/FWHM,4)
    
    info = str(evr_peakFF)+","+str(tess_peakFF)+","+str(impulse)+","+str(best_fit_temp)+"\n"
    with open("play_with_flares.csv","a") as OUT:
        OUT.write(info)
        
    #peaktime=evr_mjd_window[list(evr_fracflux).index(evr_peakFF)]
    
    #ax1.plot(peaktime,peakFF,marker="o",ms=15,color="red")
    #ax1.axvline(evr_mjd_window[list(evr_fracflux).index(MAX_VAL)],color="black")

    #ax1.plot(evr_xgrid_insec/(24.0*3600.0),evr_ygrid_insec,marker="o",ms=2,ls="none",color="mediumslateblue")
    #ax1.plot(tess_xgrid_insec/(24.0*3600.0),tess_ygrid_insec,marker="o",ms=2,ls="none",color="firebrick")
    
    #ax1.plot(tess_mjd_window, tess_fracflux, marker="+", ms=9, ls="none",color="black")

    ax1.plot(tess_mjd_window, tess_fracflux, marker="+", ms=9, ls="none",color="brown")
    
    ax1.plot(inflare_tbjd, inflare_fflux, marker="+", ms=9, ls="none",color="red")

    ax1.plot(evr_mjd_window, evr_fracflux, marker="o",ls="none",color="mediumslateblue")
    
    #info = str(i)+", "+str(TID[i])+", "+str(TID_ACTUAL_YMD)+", "+str(np.min(inwindow_tbjd))+", \n"
    #with open("list_multiband_flares.csv","a") as OUTFILE:
    #    OUTFILE.write(info)

    #plt.xticks(rotation=90.0)
    plt.xlabel("BMJD",fontsize=12)
    plt.ylabel("$\Delta$ F/F",fontsize=12)
    #plt.gca().invert_yaxis()

    ax2 = fig.add_subplot(212)
    
    ax2.plot(tbjd, tmags, marker="+", ls="none",color="black")
    ax2.plot(old_inflare_tbjd, old_inflare_tmags, marker="+", ls="none",color="red")
    #plt.xticks(rotation=90.0)
    plt.xlabel("TBJD",fontsize=12)
    plt.ylabel("TESS-mags",fontsize=12)
    plt.gca().invert_yaxis()

    plt.tight_layout()
    plt.show()
    plt.close("all")

"""
plt.hist(fl_temperatures,range=[4000,35000])
plt.xlabel("Color-temperature [K]",fontsize=14)
plt.ylabel("# flares",fontsize=14)
#plt.savefig("/home/wshoward/Desktop/BB_temps.png")
plt.show()
"""
