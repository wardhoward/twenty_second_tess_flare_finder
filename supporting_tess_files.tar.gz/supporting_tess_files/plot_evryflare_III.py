import glob
import copy
import numpy as np
import os
from astropy.stats import LombScargle
import matplotlib.pyplot as plt
from scipy.stats import sigmaclip
import scipy.signal
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit
import matplotlib
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
from matplotlib.ticker import FixedLocator, FixedFormatter
from paper_data_read_functions import read_table_two as read_table_two

#load TII from EvryFlare I:
tid_TII,apassid_TII,ra_TII,dec_TII,M_g_TII,SpT_TII,N_flares_TII,obs_time_TII,EVR_alpha_TII,EVR_alpha_err_low_TII,EVR_alpha_err_high_TII,EVR_beta_TII,EVR_beta_err_low_TII,EVR_beta_err_high_TII,superflares_TII,superflares_err_low_TII,superflares_err_high_TII,mean_log_E_TII,max_log_E_TII,mean_contrast_TII,max_contrast_TII,P_rot_TII,g_mags_TII,TESS_mags_TII = read_table_two("postref_EVR_Flare_Stars_Sect1-6_Table_II.csv") #tid_TII[P_rot_TII>0.0] has 122 rows

def linear(x, m, b):
    return m*x + b

def plot_hist(x, y, colr, y_text):

    x_min = np.nanmin(x)
    x_max = np.nanmax(x)
    
    num_bins= 5 #16

    bins = np.linspace(x_min,x_max,num=int(num_bins+1))

    counts = np.array([len(x[(x > bins[i-1]) & (x < bins[i])]) for i in range(1, len(bins))]).astype(float)

    #print counts
    #exit()

    y_counts = np.array([np.mean(y[(x > bins[i-1]) & (x < bins[i])]) for i in range(1, len(bins))]).astype(float)

    bot_arrs_err=[]
    top_arrs_err=[]
    for i in range(1,len(bins)):
        sub_arr = y[(x > bins[i-1]) & (x < bins[i])]

        #print sub_arr

        mean_array = []
        for j in range(100):
            drop_ind = int(np.random.random()*len(sub_arr))
            incl_ind = np.array([d for d in np.arange(len(sub_arr)) if d!=drop_ind])
            mean_array.append(np.mean(sub_arr[incl_ind]))
        mean_array=np.array(mean_array)
        
        #med_arr_val, bot_err, top_err = compute_1sigma_CI(mean_array)
        #bot_arrs_err.append(bot_err)
        #top_arrs_err.append(top_err)
        bot_arrs_err.append(np.std(mean_array))
        top_arrs_err.append(np.std(mean_array))
    bot_arrs_err=np.array(bot_arrs_err)
    top_arrs_err=np.array(top_arrs_err)

    y_errs = np.array([np.std(y[(x > bins[i-1]) & (x < bins[i])]) for i in range(1, len(bins))]).astype(float)

    # Plot results:
    fig, ax = plt.subplots()

    bar_width = abs(np.max(bins)-np.min(bins))/(num_bins)
    opacity = 0.8 #r0.6

    rects1 = plt.bar(bins[:-1], y_counts, bar_width, yerr=[bot_arrs_err,top_arrs_err], edgecolor='black', alpha=opacity, color=colr)

    if colr=="cornflowerblue":
        plt.ylim(32.0, 34.5)
    elif colr=="orange":
        plt.ylim(8000, 22000)
    
    plt.ylabel(y_text, fontsize=16)
    plt.xticks(fontsize=16)
    plt.yticks(fontsize=16)
    plt.legend(loc="upper right",fontsize=16)
    plt.xlabel("Mass [M$_{\odot}$]",fontsize=16)
    plt.tight_layout()
    plt.savefig(colr+".png")
    plt.show()
    #exit()
    return

def plot_var1_vs_var2(phase, ED):

    #fig, ax = plt.subplots(1,1)

    BINS=8
    
    bins = np.linspace(np.min(phase),np.max(phase),num=(BINS+1))

    counts = np.array([len(ED[(phase >= bins[i-1]) & (phase < bins[i]) & (ED>20000.0)]) for i in range(1, len(bins))]).astype(float)
    
    num_bins=len(bins)
    bar_width = (bins[1]-bins[0])#/10.0 #1.0
    #bar_width = abs(np.max(bins)-np.min(bins))/(num_bins)
    opacity = 0.8  

    fig, ax = plt.subplots(1,1,figsize=(6,3.6))
    xdata = (0.5*bar_width+bins[:-1])
    plt.bar(xdata, counts, bar_width,edgecolor='black', color="grey",label="with superflare")
    plt.show()
      
    plt.close("all")
    
    return (bins[:-1], counts)

def compute_1sigma_CI(input_array):

    sorted_input_array = np.sort(input_array)

    low_ind = int(0.16*len(input_array))
    high_ind = int(0.84*len(input_array))

    bot_val = (sorted_input_array[:low_ind])[-1]
    top_val = (sorted_input_array[high_ind:])[0]

    bot_arr_err = abs(np.nanmedian(input_array) - bot_val)
    top_arr_err = abs(np.nanmedian(input_array) - top_val)

    return (np.median(input_array), bot_arr_err, top_arr_err)

"""
def get_new_masses_postref():

    readj_i=[]
    readj_TIC=[]
    readj_mass=[]
    readj_e_mass=[]
    with open("readjusted_new_masses_ref.csv","r") as INFILE:
        for lines in INFILE:
            readj_i.append(int(lines.split(",")[0]))
            readj_TIC.append(int(lines.split(",")[1]))
            readj_mass.append(float(lines.split(",")[2]))
            readj_e_mass.append(float(lines.split(",")[3]))
    readj_i=np.array(readj_i)
    readj_TIC=np.array(readj_TIC)
    readj_mass=np.array(readj_mass)
    readj_e_mass=np.array(readj_e_mass)

    return (readj_i, readj_TIC, readj_mass, readj_e_mass)
"""

def binary_classical_or_complex():

    mSorC_i=[]
    mSorC_desig=[]
    with open("mostly_simple_vs_mostly_complex.csv","r") as INFILE:
        next(INFILE)
        for lines in INFILE:
            mSorC_i.append(int(lines.split(",")[0]))
            mSorC_desig.append(str(lines.split(",")[1].rstrip("\n")))
    mSorC_i = np.array(mSorC_i)
    mSorC_desig = np.array(mSorC_desig).astype(str)

    return (mSorC_i, mSorC_desig)

print ("\n")

uvc_i=[]
uvc_TIC_ID=[]
uvc_log_UVC_energy=[]
uvc_UVC_surface_flux=[]
uvc_mass=[]
with open("HZ_fluxes.csv","r") as INFILE:
    for lines in INFILE:
        uvc_i.append(float(lines.split(",")[0]))
        uvc_TIC_ID.append(float(lines.split(",")[1]))
        uvc_log_UVC_energy.append(float(lines.split(",")[2]))
        uvc_UVC_surface_flux.append(float(lines.split(",")[3]))
        uvc_mass.append(float(lines.split(",")[4]))
uvc_i = np.array(uvc_i)
uvc_TIC_ID = np.array(uvc_TIC_ID)
log_UVC_energy = np.array(uvc_log_UVC_energy)
UVC_surface_flux = np.array(uvc_UVC_surface_flux)
uvc_mass = np.array(uvc_mass)


add_i=[]
inst_temp=[]
inst_temp_low=[]
inst_temp_upp=[]
with open("temperature_info_addendum.csv","r") as ADDENDUM:
    for lines in ADDENDUM:
        add_i.append(int(lines.split(",")[0]))
        inst_temp.append(float(lines.split(",")[1]))
        inst_temp_low.append(float(lines.split(",")[2]))
        inst_temp_upp.append(float(lines.split(",")[3]))
add_i=np.array(add_i)
inst_temp=np.array(inst_temp)
inst_temp_low=np.array(inst_temp_low)
inst_temp_upp=np.array(inst_temp_upp)

peak_i=[]
evry_pk_err=[]
tess_pk_err=[]
with open("peak_info_addendum.csv","r") as ADDENDUM:
    for lines in ADDENDUM:
        peak_i.append(int(lines.split(",")[0]))
        evry_pk_err.append(float(lines.split(",")[1]))
        tess_pk_err.append(float(lines.split(",")[2]))
peak_i=np.array(peak_i)
evry_pk_err=np.array(evry_pk_err)
tess_pk_err=np.array(tess_pk_err)

above_i=[]
T_abv_30K=[]
T_abv_20K=[]
T_abv_14K=[]
with open("time_in_excess.csv","r") as INFILE:
    next(INFILE)
    for lines in INFILE:
        above_i.append(float(lines.split(",")[0]))
        T_abv_30K.append(float(lines.split(",")[1]))
        T_abv_20K.append(float(lines.split(",")[2]))
        T_abv_14K.append(float(lines.split(",")[3]))
above_i=np.array(above_i)
T_abv_30K=np.array(T_abv_30K)*24.0*60.0
T_abv_20K=np.array(T_abv_20K)*24.0*60.0
T_abv_14K=np.array(T_abv_14K)*24.0*60.0
#T_abv_14K[T_abv_14K>]=1.0
#print len(above_i)
#exit()

I=[] #0
TIC=[] #1
SOURCETYPE=[] #2
MOVING_GROUP=[] #3
BIN_AGE=[] #4
AGE=[] #5
with open("short_vers_new_ages_ref.csv","r") as INFILE:
    next(INFILE)
    for lines in INFILE:
        BIN_AGE.append(str(lines.split(",")[4]))
        AGE.append(float(lines.split(",")[5].rstrip("\n")))
BIN_AGE = np.array(BIN_AGE)
AGE = np.array(AGE)
        

#i, TIC_ID, RA, Dec, Year, Mon, Day, HR, Min, g_mags, TESS_mags, distance, SpT, mass, Prot, Ro, Evry_Erg, e_Evry_Erg, TESS_erg, e_TESS_Erg, evr_peakFF, tess_peakFF, n_peaks, tot_BB_data, e_tot_BB_data, tot_BB_data_trap, e_tot_BB_data_trap, E_tot_BB_data_trap, tot_BB_sampl, e_tot_BB_sampl, E_tot_BB_sampl, FWHM_BB_data, e_FWHM_BB_data, FWHM_BB_sampl, e_FWHM_BB_sampl, E_FWHM_BB_sampl, FWHM, impulse

i=[] #0
TIC_ID=[] #1
RA=[] #2
Dec=[] #3
Year=[] #4
Mon=[] #5
Day=[] #6
HR=[] #7
Min=[] #8
g_mags=[] #9
TESS_mags=[] #10
distance=[] #11
SpT=[] #12
mass=[] #13
Prot=[] #14
Ro=[] #15
Evry_Erg=[] #16
e_Evry_Erg=[] #17
TESS_erg=[] #18
e_TESS_Erg=[] #19
evr_peakFF=[] #20
tess_peakFF=[] #21
n_peaks=[] #22
tot_BB_data=[] #23
e_tot_BB_data=[] #24
tot_BB_data_trap=[] #25
e_tot_BB_data_trap=[] #26
E_tot_BB_data_trap=[] #27
tot_BB_sampl=[] #28
e_tot_BB_sampl=[] #29
E_tot_BB_sampl=[] #30
FWHM_BB_data=[] #31
e_FWHM_BB_data=[] #32
FWHM_BB_sampl=[] #33
e_FWHM_BB_sampl=[] #34
E_FWHM_BB_sampl=[] #35
FWHM=[] #36
impulse=[] #37

with open("evryflare_III_table_I.csv","r") as INFILE:
    next(INFILE)
    for lines in INFILE:
        i.append(int(lines.split(",")[0])) #0
        TIC_ID.append(int(lines.split(",")[1])) #1
        RA.append(float(lines.split(",")[2])) #2
        Dec.append(float(lines.split(",")[3])) #3
        Year.append(int(lines.split(",")[4])) #4
        Mon.append(int(lines.split(",")[5])) #5
        Day.append(int(lines.split(",")[6])) #6
        HR.append(int(lines.split(",")[7])) #7
        Min.append(int(lines.split(",")[8])) #8
        g_mags.append(float(lines.split(",")[9])) #9
        TESS_mags.append(float(lines.split(",")[10])) #10
        distance.append(float(lines.split(",")[11])) #11
        SpT.append(str(lines.split(",")[12])) #12
        mass.append(float(lines.split(",")[13])) #13
        Prot.append(float(lines.split(",")[14])) #14
        Ro.append(float(lines.split(",")[15])) #15
        Evry_Erg.append(float(lines.split(",")[16])) #16
        e_Evry_Erg.append(float(lines.split(",")[17])) #17
        TESS_erg.append(float(lines.split(",")[18])) #18
        e_TESS_Erg.append(float(lines.split(",")[19])) #19
        evr_peakFF.append(float(lines.split(",")[20])) #20
        tess_peakFF.append(float(lines.split(",")[21])) #21
        n_peaks.append(int(lines.split(",")[22])) #22
        tot_BB_data.append(float(lines.split(",")[23])) #23
        e_tot_BB_data.append(float(lines.split(",")[24])) #24
        tot_BB_data_trap.append(float(lines.split(",")[25])) #25
        e_tot_BB_data_trap.append(float(lines.split(",")[26])) #26
        E_tot_BB_data_trap.append(float(lines.split(",")[27])) #27
        tot_BB_sampl.append(float(lines.split(",")[28])) #28
        e_tot_BB_sampl.append(float(lines.split(",")[29])) #29
        E_tot_BB_sampl.append(float(lines.split(",")[30])) #30
        FWHM_BB_data.append(float(lines.split(",")[31])) #31
        e_FWHM_BB_data.append(float(lines.split(",")[32])) #32
        FWHM_BB_sampl.append(float(lines.split(",")[33])) #33
        e_FWHM_BB_sampl.append(float(lines.split(",")[34])) #34
        E_FWHM_BB_sampl.append(float(lines.split(",")[35])) #35
        FWHM.append(float(lines.split(",")[36])) #36
        impulse.append(float(lines.split(",")[37])) #37
        
TIC_ID=np.array(TIC_ID)
mass = np.array(mass)
FWHM = np.array(FWHM)
g_mags= np.array(g_mags)
distance= np.array(distance)
Evry_Erg = np.array(Evry_Erg)
TESS_Erg = np.array(TESS_erg)
e_Evry_Erg = np.array(e_Evry_Erg)
Evry_Erg_bol = np.log10((10.0**Evry_Erg)/0.19)
SpT = np.array(SpT)
FWHM_BB_data = np.array(FWHM_BB_data)
tot_BB_data = np.array(tot_BB_data)
e_FWHM_BB_data = np.array(e_FWHM_BB_data)
e_tot_BB_data = np.array(e_tot_BB_data)
FWHM_BB_sampl = np.array(FWHM_BB_sampl)
tot_BB_sampl = np.array(tot_BB_sampl)
tot_BB_data_trap=np.array(tot_BB_data_trap)
e_tot_BB_data_trap=np.array(e_tot_BB_data_trap)
E_tot_BB_data_trap=np.array(E_tot_BB_data_trap)
impulse = np.array(impulse)
evr_peakFF = np.array(evr_peakFF)
tess_peakFF = np.array(tess_peakFF)
color = evr_peakFF - tess_peakFF
n_peaks = np.array(n_peaks).astype(float)
Ro = np.array(Ro)
Prot = np.array(Prot)

print Evry_Erg_bol[mass<0.2]
exit()

e_FWHM_BB_data[e_FWHM_BB_data<300.0]=300.0
e_tot_BB_data[e_tot_BB_data<300.0]=300.0

e_color = np.absolute(color)*np.sqrt((evry_pk_err/evr_peakFF)**2.0 + (tess_pk_err/tess_peakFF)**2.0)
e_impulse = np.absolute(impulse)*np.sqrt((evry_pk_err/evr_peakFF)**2.0 + (1.0/FWHM)**2.0)

mSorC_i, mSorC_desig = binary_classical_or_complex()

plt.axhline(0.3, color="grey")
plt.loglog(10.0**TESS_Erg[mass<=0.42], evr_peakFF[mass<=0.42], marker="o",ls="none", color="firebrick")
plt.loglog(10.0**TESS_Erg[mass>0.42], evr_peakFF[mass>0.42], marker="o",ls="none", color="mediumpurple")

plt.xlabel("Flare Energy in $T$ [erg]")
plt.ylabel("Flare Ampl. in $g^{\prime}$ [FF]")
plt.show()
exit()


#print TIC_ID[mass==0.42]
#exit()
#readj_i, readj_TIC, readj_mass, readj_e_mass = get_new_masses_postref()


#superflares_TII,superflares_err_low_TII,superflares_err_high_TII,mass,log_UVC_energy,Ro,Prot,UVC_surface_flux

supers=[]
for y in range(len(i)):
    TID = TIC_ID[y]
    if len(superflares_TII[tid_TII==TID])>0:
        supers.append(superflares_TII[tid_TII==TID][0])
    else:
        supers.append(-1.0)
supers=np.array(supers)

print Prot

#count=0
bool_age=[]
for y in range(len(BIN_AGE)):
    if BIN_AGE[y]=="YOUNG":
        bool_age.append(1)
    else:
        bool_age.append(0)
    #if (BIN_AGE[y]=="YOUNG") and (AGE[y]<0.0):
    #    AGE[y] = 1000.0
    #    count+=1
    #if (BIN_AGE[y]=="N/A") and (AGE[y]<0.0):
    #    AGE[y] = 3000.0
#print count,"non YMG members"
#exit()

bool_age = np.array(bool_age)

clean_UVC_surface_flux = UVC_surface_flux[(Ro>0.0)]
clean_Ro = Ro[(Ro>0.0)]
clean_Prot = Prot[(Ro>0.0)]

"""
popt, pcov = curve_fit(linear, Evry_Erg, np.log10(UVC_surface_flux))
log_x_arr = np.linspace(0.999*np.min(Evry_Erg), 1.001*np.max(Evry_Erg), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
fit_log_data =  10.0**linear(Evry_Erg, *popt)

plt.loglog(10.0**Evry_Erg, UVC_surface_flux, marker="o",ls="none")
plt.loglog(10.0**Evry_Erg,fit_log_data,color="red")
plt.show()

plt.plot(Evry_Erg, np.log10((UVC_surface_flux/fit_log_data)), marker="o",ls="none")
plt.show()

plt.loglog(Ro[(Ro>0.0)], UVC_surface_flux[(Ro>0.0)]/fit_log_data[Ro>0.0], marker="o", ls="none")
plt.show()
exit()
"""

#print clean_Prot
#plt.hist(clean_UVC_surface_flux[clean_Ro>0.2],color="orange",alpha=0.333)
#plt.hist(clean_UVC_surface_flux[clean_Ro<=0.2],color="cornflowerblue",alpha=0.333)
#plt.show()
#exit()
#plt.hist(UVC_surface_flux[bool_age==1],color="cyan",range=[0,500])
#plt.hist(UVC_surface_flux[bool_age==0],color="orange",range=[0,500])
#plt.show()

#exit()
#print len(Ro)
#exit()
#plt.plot(mass, UVC_surface_flux, marker="o", ls="none")
#plt.plot(AGE[AGE>0.0], UVC_surface_flux[AGE>0.0], marker="o", ls="none")
#plt.plot(AGE[(AGE>0.0)&(Ro>0.0)], Ro[(AGE>0.0)&(Ro>0.0)], marker="o", ls="none")

#plt.loglog(Ro[(Ro>0.0)&(mass<=0.42)], UVC_surface_flux[(Ro>0.0)&(mass<=0.42)], marker="o", ls="none",color="salmon")
#plt.loglog(Ro[(Ro>0.0)&(mass>0.42)], UVC_surface_flux[(Ro>0.0)&(mass>0.42)], marker="o", ls="none",color="mediumpurple")

#plt.plot(mass[(AGE>0.0)&(AGE<500.0)], UVC_surface_flux[(AGE>0.0)&(AGE<500.0)], marker="o", ms=12, ls="none",color="yellow",alpha=0.666)
#plt.plot(mass[(AGE>0.0)&(AGE>=500.0)], UVC_surface_flux[(AGE>0.0)&(AGE>=500.0)], marker="o", ms=12, ls="none",color="lightgrey",alpha=0.9)

#plt.axhline(np.median(UVC_surface_flux[(AGE>0.0)&(AGE<500.0)&(mass<=0.42)]),color="orange")
#plt.axhline(np.median(UVC_surface_flux[(AGE>0.0)&(AGE>=500.0)&(mass<=0.42)]),color="grey")

"""
real_diff_late = np.median(UVC_surface_flux[(AGE>0.0)&(AGE<500.0)&(mass<=0.42)]) - np.median(UVC_surface_flux[(AGE>0.0)&(AGE>=500.0)&(mass<=0.42)])

print real_diff_late
#exit()


yng_mass = mass[(AGE>0.0)&(AGE<500.0)]
old_mass = mass[(AGE>0.0)&(AGE>=500.0)]
young_UV = UVC_surface_flux[(AGE>0.0)&(AGE<500.0)]
old_UV = UVC_surface_flux[(AGE>0.0)&(AGE>=500.0)]

# is there an age difference as a function of mass?
trials = 10000

diff_late=[]
diff_early=[]
for y in range(trials):
    MC_young_UV =copy.deepcopy(young_UV)
    MC_old_UV =copy.deepcopy(old_UV)

    np.random.shuffle(MC_young_UV)
    np.random.shuffle(MC_old_UV)

    late_MC_MED_YNG = np.median(MC_young_UV[yng_mass<=0.42])
    late_MC_MED_OLD = np.median(MC_old_UV[old_mass<=0.42])
    early_MC_MED_YNG = np.median(MC_young_UV[yng_mass>0.42])
    early_MC_MED_OLD = np.median(MC_old_UV[old_mass>0.42])

    diff_late.append(late_MC_MED_YNG - late_MC_MED_OLD)
    diff_early.append(early_MC_MED_YNG - early_MC_MED_OLD)
diff_late=np.array(diff_late)
diff_early=np.array(diff_early)

plt.close("all")
RD = (1.0*len(diff_late[diff_late>real_diff_late]))/(1.0*len(diff_late))
plt.title(RD)
plt.hist(diff_late)
plt.show()
    
#plt.plot(mass[(mass<=0.42)], UVC_surface_flux[(mass<=0.42)], marker="o", ls="none",color="salmon")
#plt.plot(mass[(mass>0.42)], UVC_surface_flux[(mass>0.42)], marker="o", ls="none",color="mediumpurple")

plt.show() #log_UVC_energy
exit()
"""

import matplotlib.colors as colors

def truncate_colormap(cmap, minval=0.0, maxval=1.0, n=100):
    new_cmap = colors.LinearSegmentedColormap.from_list(
        'trunc({n},{a:.2f},{b:.2f})'.format(n=cmap.name, a=minval, b=maxval),
        cmap(np.linspace(minval, maxval, n)))
    return new_cmap

cmap=plt.cm.plasma_r

#cmap = truncate_colormap(cmap, -1.8, -0.22) #superflare rate vers

c = np.log10(Ro[(AGE>0.0)&(Ro>0.0)])

sm = plt.cm.ScalarMappable(cmap=cmap)
sm._A = copy.deepcopy(c)

cbar = plt.colorbar(sm)
cbar.ax.tick_params(labelsize=12)
cbar.set_label(r"log Rossby number",fontsize=12)

#plt.loglog(AGE[(AGE>0.0)&(mass<=0.42)], UVC_surface_flux[(AGE>0.0)&(mass<=0.42)], marker="o", ls="none",color="salmon",alpha=0.0001)
#plt.loglog(AGE[(AGE>0.0)&(mass>0.42)], UVC_surface_flux[(AGE>0.0)&(mass>0.42)], marker="o", ls="none",color="purple",alpha=0.0001)

plt.scatter(AGE[(AGE>0.0)&(Ro>0.0)], UVC_surface_flux[(AGE>0.0)&(Ro>0.0)], marker="o", s=51,c=c, cmap=cmap,zorder=9) #actual ages
plt.scatter(AGE[(AGE>500.0)&(Ro>0.0)&(AGE<1100.0)], UVC_surface_flux[(AGE>500.0)&(Ro>0.0)&(AGE<1100.0)], marker="o", s=5,color="white",zorder=10) #actual ages

print TIC_ID[(AGE>500.0)&(Ro>0.0)&(AGE<1100.0)]

# [5796048 140045538 142086812 140045538 142086812 140045538 140045538 140045538 140045538 140045538 140045538]

#exit()
#plt.errorbar(np.array([100,800]), np.array([138,4]), yerr=[np.array([125, 4]),np.array([780, 138])],marker="o",ls="none")
#plt.scatter(np.array([100,800]), np.array([138,4]), s=51, color="black")
#plt.errorbar(np.array([800]), np.array([291]), yerr=np.array([4, 138]), marker="o",ls="-")

plt.xlim(-20.0, 460.0)

plt.yscale('log')
plt.xticks(fontsize=11)
plt.yticks(fontsize=11)

plt.xlabel(r"Stellar age [Myr]",fontsize=13)
plt.ylabel(r"UVC flux at HZ distance [W/m$^2$]",fontsize=13)

plt.tight_layout()
plt.savefig("age_vs_uvc_HZ.pdf")
plt.show()

c = np.log10(Ro)

print "---Rossby---\n"
print Ro[Ro>0.2]
print ""
print Ro[Ro<0.2]
exit()

sm = plt.cm.ScalarMappable(cmap=cmap)
sm._A = copy.deepcopy(c)

cbar = plt.colorbar(sm)
cbar.ax.tick_params(labelsize=12)
cbar.set_label(r"log Rossby number",fontsize=12)

#fig, ax = plt.subplots()

#plt.loglog(mass, UVC_surface_flux, marker="o", ls="none",alpha=0.0001)

plt.axvline(0.33,color="red",ls="--")
plt.text(0.295, 0.013,"0.33 M$_\odot$",rotation=90.0,fontsize=13,color="red")

plt.scatter(mass, UVC_surface_flux, marker="o", s=51,c=c, cmap=cmap,zorder=9) #actual ages

#print np.mean(UVC_surface_flux[mass<=0.33]),np.mean(UVC_surface_flux[mass>0.33])
#exit()
#ax.get_xaxis().set_major_formatter(
#    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

plt.yscale('log')
#plt.xscale('log')
plt.xticks(fontsize=11)
plt.yticks(fontsize=11)

plt.xlabel(r"Stellar mass [M$_\odot$]",fontsize=13)
plt.ylabel(r"UVC flux at HZ distance [W/m$^2$]",fontsize=13)

plt.tight_layout()
plt.savefig("mass_vs_uvc_HZ.pdf")
plt.show()
#exit()

orig_ages = AGE[(AGE>0.0)]
orig_UV = UVC_surface_flux[(AGE>0.0)]

trials = 10000

median_differences=[]
for t in np.arange(trials):
    MC_ages = copy.deepcopy(orig_ages)
    MC_UV = copy.deepcopy(orig_UV)

    np.random.shuffle(MC_UV)

    MED_DIFF = abs(np.median(MC_UV[MC_ages<500.0]) - np.median(MC_UV[MC_ages>=500.0]))
    median_differences.append(MED_DIFF)
median_differences=np.array(median_differences)

#frac = (1.0*len(median_differences[median_differences>134.0]))/(1.0*len(median_differences))
#plt.title(frac)
#plt.hist(median_differences,color="salmon")
#plt.show()

#exit()

#plt.hist(UVC_surface_flux[(AGE>500.0)&(Ro>0.0)],range=[0,300],color="orange",alpha=0.5)
#plt.hist(UVC_surface_flux[(AGE>0.0)&(Ro>0.0)&(AGE<500.0)],range=[0,300],color="cornflowerblue",alpha=0.5)
#plt.show()

#med_UV_old, bot_UV_old, top_UV_old = compute_1sigma_CI(UVC_surface_flux[(AGE>500.0)])

med_UV_young, bot_UV_young, top_UV_young = compute_1sigma_CI(UVC_surface_flux[(AGE>0.0)&(AGE<500.0)])

#med_UV_weird, bot_UV_weird, top_UV_weird = compute_1sigma_CI(UVC_surface_flux[AGE<0.0])

#print len(mass[mass>0.33]),len(mass[mass<=0.33])
#print "old", med_UV_old, bot_UV_old, top_UV_old,"med"
#print "young", med_UV_young, bot_UV_young, top_UV_young
#print "weird",med_UV_weird, bot_UV_weird, top_UV_weird

"""
plt.loglog(10.0**Evry_Erg, FWHM_BB_data, marker="o", ls="none")
plt.loglog(10.0**Evry_Erg[mSorC_desig=="S"], FWHM_BB_data[mSorC_desig=="S"], marker="o", ls="none", color="orange")
plt.show()

plt.loglog(10.0**Evry_Erg, tot_BB_data_trap, marker="o", ls="none")
plt.loglog(10.0**Evry_Erg[mSorC_desig=="S"], tot_BB_data_trap[mSorC_desig=="S"], marker="o", ls="none", color="orange")
plt.show()

plt.loglog(impulse, FWHM_BB_data, marker="o", ls="none")
plt.loglog(impulse[mSorC_desig=="S"], FWHM_BB_data[mSorC_desig=="S"], marker="o", ls="none", color="orange")
plt.show()

plt.loglog(impulse, tot_BB_data_trap, marker="o", ls="none")
plt.loglog(impulse[mSorC_desig=="S"], tot_BB_data_trap[mSorC_desig=="S"], marker="o", ls="none", color="orange")
plt.show()
"""

fig, ax = plt.subplots(figsize=(6,7))
plt.axis('off')

ax1 = fig.add_subplot(2,1,1)

#tot_BB_data_trap, e_tot_BB_data_trap, E_tot_BB_data_trap

popt, pcov = curve_fit(linear, Evry_Erg, np.log10(FWHM_BB_data))
log_x_arr = np.linspace(0.999*np.min(Evry_Erg), 1.001*np.max(Evry_Erg), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)

ax1.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax1.errorbar(10.0**Evry_Erg[mSorC_desig=="C"], FWHM_BB_data[mSorC_desig=="C"], xerr=(10.0**e_Evry_Erg[mSorC_desig=="C"]), yerr=1.25*e_FWHM_BB_data[mSorC_desig=="C"], marker="o", ms=5, ls="none", color="teal",label="Complex")
ax1.errorbar(10.0**Evry_Erg[mSorC_desig=="S"], FWHM_BB_data[mSorC_desig=="S"], xerr=(10.0**e_Evry_Erg[mSorC_desig=="S"]), yerr=1.25*e_FWHM_BB_data[mSorC_desig=="S"], marker="o", ms=5, ls="none", color="sandybrown",label="Classical")

legend = ax1.legend(loc="lower right",fontsize=13)
frame = legend.get_frame()
frame.set_facecolor('gainsboro')

ax1.set_xscale("log")
ax1.set_yscale("log")
ax1.set_xlabel("Energy in $g^{\prime}$ [erg]", fontsize=14)
ax1.set_ylabel("Peak $T_\mathrm{Eff}$  [K]", fontsize=14)

y_formatter = FixedFormatter(['', '', '5,000', '', '', '', '', '20,000', '', '40,000', ''])
y_locator = FixedLocator([3000, 4000, 5000, 6000, 7000, 8000, 9000, 20000, 30000, 40000, 50000])
ax1.yaxis.set_minor_formatter(y_formatter)
ax1.yaxis.set_minor_locator(y_locator)

ax1.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax1.tick_params(labelsize=12)
for tick in ax1.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12)

ax2 = fig.add_subplot(2,1,2)

popt, pcov = curve_fit(linear, np.log10(impulse), np.log10(FWHM_BB_data))
log_x_arr = np.linspace(0.999*np.min(np.log10(impulse)), 1.001*np.max(np.log10(impulse)), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)

ax2.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax2.errorbar(impulse[mSorC_desig=="C"], FWHM_BB_data[mSorC_desig=="C"], xerr=e_impulse[mSorC_desig=="C"], yerr=1.25*e_FWHM_BB_data[mSorC_desig=="C"], marker="o", ms=5, ls="none", color="teal")
ax2.errorbar(impulse[mSorC_desig=="S"], FWHM_BB_data[mSorC_desig=="S"], xerr=e_impulse[mSorC_desig=="S"], yerr=1.25*e_FWHM_BB_data[mSorC_desig=="S"], marker="o", ms=5, ls="none", color="sandybrown")

ax2.set_xscale("log")
ax2.set_yscale("log")
ax2.set_xlabel("Impulse [Ampl./FWHM]", fontsize=14)
ax2.set_ylabel("Peak $T_\mathrm{Eff}$  [K]", fontsize=14)

y_formatter = FixedFormatter(['', '', '5,000', '', '', '', '', '20,000', '', '40,000', ''])
y_locator = FixedLocator([3000, 4000, 5000, 6000, 7000, 8000, 9000, 20000, 30000, 40000, 50000])
ax2.yaxis.set_minor_formatter(y_formatter)
ax2.yaxis.set_minor_locator(y_locator)

ax2.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax2.tick_params(labelsize=12)
for tick in ax2.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12) 

plt.tight_layout()
plt.savefig("classical_vs_complex_flares.png")
plt.show()
    
#exit()



"""
head = "TIC_ID"+","+"ObsDateTime"+","+"Evry_Energy"+","+"TESS_Energy"+","+"Evry_peakFF"+","+"TESS_peakFF"+","+"Color"+","+"e_Color"+","+"peak_BB_Teff"+","+"e_peak_BB_Teff"+","+"tot_BB_Teff"+","+"e_tot_BB_Teff"+","+"E_tot_BB_Teff"+","+"Time_abv_14K"+","+"Impulse"+","+"e_Impulse"+","+"Prot"+","+"Mass"+"\n"
with open("table_APDX_Teff.csv","a") as OUTFILE:
    OUTFILE.write(head)

for j in range(len(TIC_ID)):

    STR_YR = str(Year[j])
    STR_MON = str(Mon[j])
    STR_DAY = str(Day[j])
    STR_HR = str(HR[j])
    STR_MIN = str(Min[j])

    PROT = Prot[j]
    if PROT<0.0:
        PROT="-"
    else:
        PROT = str(PROT)
    
    if len(STR_MON)<2:
        STR_MON = "0"+STR_MON
    if len(STR_DAY)<2:
        STR_DAY = "0"+STR_DAY
    if len(STR_HR)<2:
        STR_HR = "0"+STR_HR
    if len(STR_MIN)<2:
        STR_MIN = "0"+STR_MIN
    STR_DATE = STR_YR+"-"+STR_MON+"-"+STR_DAY+" "+STR_HR+":"+STR_MIN
    #print STR_DATE
    
    info = str(TIC_ID[j])+","+STR_DATE+","+str(Evry_Erg[j])+","+str(TESS_erg[j])+","+str(evr_peakFF[j])+","+str(tess_peakFF[j])+","+str(np.round(color[j],3))+","+str(np.round(e_color[j],3))+","+str(int(FWHM_BB_data[j]))+","+str(int(e_FWHM_BB_data[j]))+","+str(int(tot_BB_data_trap[j]))+","+str(int(e_tot_BB_data_trap[j]))+","+str(int(E_tot_BB_data_trap[j]))+","+str(np.round(T_abv_14K[j],1))+","+str(np.round(impulse[j],3))+","+str(np.round(e_impulse[j],3))+","+str(PROT)+","+str(mass[j])+"\n"
    with open("table_APDX_Teff.csv","a") as OUTFILE:
        OUTFILE.write(info)
    #exit()
#tot_BB_data_trap, e_tot_BB_data_trap, E_tot_BB_data_trap
#exit()
"""

print len([x for x in SpT if "K" in x]),"K-dwarf flares"
print len([x for x in SpT if "M" in x]),"M-dwarf flares"
#exit()

print np.mean(FWHM_BB_data[mass<=0.42])
print np.mean(FWHM_BB_data[mass>0.42])
late_mean_FWHM_BB, late_bot_FWHM_BB_err, late_top_FWHM_BB_err = compute_1sigma_CI(FWHM_BB_data[mass<=0.42])
early_mean_FWHM_BB, early_bot_FWHM_BB_err, early_top_FWHM_BB_err = compute_1sigma_CI(FWHM_BB_data[mass>0.42])

print late_mean_FWHM_BB, late_bot_FWHM_BB_err, late_top_FWHM_BB_err,"K"
print early_mean_FWHM_BB, early_bot_FWHM_BB_err, early_top_FWHM_BB_err,"K"
#exit()

print np.min(Evry_Erg),np.max(Evry_Erg)
print np.min(evr_peakFF),np.max(evr_peakFF)
print len(T_abv_14K[T_abv_14K>0.0])/44.0
print len(T_abv_20K[T_abv_20K>0.0])/44.0
print len(T_abv_30K[T_abv_30K>0.0])/44.0

mean_FWHM_BB, bot_FWHM_BB_err, top_FWHM_BB_err = compute_1sigma_CI(FWHM_BB_data)
mean_tot_BB, bot_tot_BB_err, top_tot_BB_err = compute_1sigma_CI(tot_BB_data_trap)
print "FWHM", mean_FWHM_BB, bot_FWHM_BB_err, top_FWHM_BB_err,"K"
print "tot trap", mean_tot_BB, bot_tot_BB_err, top_tot_BB_err,"K"
#exit()
popt, pcov = curve_fit(linear, TESS_Erg, Evry_Erg)
log_x_arr = np.linspace(np.min(TESS_Erg), np.max(TESS_Erg), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)

plt.loglog(10.0**log_x_arr, fit_log_line, linewidth=3, color="tomato")
plt.loglog(10.0**TESS_Erg, 10.0**Evry_Erg, marker="o",ls="none",color="black")

plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.xlabel("Energy in $T$ [erg]",fontsize=14)
plt.ylabel("Energy in $g^{\prime}$ [erg]",fontsize=14)
plt.tight_layout()
plt.savefig("energy_evry_tess_pwrlaw.png")
plt.show()

print "energ",popt

popt, pcov = curve_fit(linear, np.log10(tess_peakFF), np.log10(evr_peakFF))
log_x_arr = np.linspace(np.min(np.log10(tess_peakFF)), np.max(np.log10(tess_peakFF)), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "ampl",popt

plt.loglog(10.0**log_x_arr, fit_log_line, linewidth=3, color="orange")
plt.loglog(tess_peakFF, evr_peakFF, marker="o",ls="none",color="black")

plt.xticks(fontsize=13)
plt.yticks(fontsize=13)
plt.xlabel("Amplitude in $T$ [normalized flux]",fontsize=14)
plt.ylabel("Amplitude in $g^{\prime}$ [normalized flux]",fontsize=14)
plt.tight_layout()
plt.savefig("ampl_evry_tess_pwrlaw.png")
plt.show()

#exit()

#plot_hist(mass, FWHM_BB_data, "orange", "T$_\mathrm{Eff}$")
#plot_hist(mass, Evry_Erg, "cornflowerblue", "Energy [log erg]")
#exit()

#plt.loglog(10**Evry_Erg[mass<=0.42], evr_peakFF[mass<=0.42], marker="o", ls="none", color="darkorange")
#plt.loglog(10**Evry_Erg[mass>0.42], evr_peakFF[mass>0.42], marker="o", ls="none", color="mediumpurple")
#plt.show()

#plt.hist(evr_peakFF[mass<=0.42],color="darkorange",range=[0,1.5])
#plt.hist(evr_peakFF[mass>0.42],color="mediumpurple",range=[0,1.5])
#plt.show()

"""
import corner

ndim, nsamples = 2, 10000
np.random.seed(42)

sample_log_energy = np.concatenate((Evry_Erg,Evry_Erg,Evry_Erg,Evry_Erg,Evry_Erg,Evry_Erg,Evry_Erg,Evry_Erg))
sample_log_BB = np.concatenate((np.log10(FWHM_BB_data),np.log10(FWHM_BB_data),np.log10(FWHM_BB_data),np.log10(FWHM_BB_data),np.log10(FWHM_BB_data),np.log10(FWHM_BB_data),np.log10(FWHM_BB_data),np.log10(FWHM_BB_data)))
sample_mass = np.concatenate((mass,mass,mass,mass,mass,mass,mass,mass))

sample_log_energy = np.random.normal(sample_log_energy, 0.2)
sample_log_BB = np.random.normal(sample_log_BB, 1.5)
sample_mass = np.random.normal(sample_mass, 0.05)

#samples = np.random.randn(ndim * nsamples).reshape([nsamples, ndim])
samples = np.vstack((sample_mass, sample_log_energy, sample_log_BB)).T
print samples.shape

figure = corner.corner(samples, labels=[r"Mass [M$_\odot$]", r"$\log$ E [erg]", r"log T$_{Eff}$"], show_titles=True, title_kwargs={"fontsize": 11})
plt.savefig("cornerplot.png")
plt.show()
exit()
"""

from scipy import stats

#actual_KS_test_val, actual_KS_p_val = stats.ks_2samp(good_superflares[(good_ro>=0.04)&(good_ro<0.44)], good_superflares[(good_ro>=0.44)])

actual_AD_test_val, out_array, actual_AD_p_val = stats.anderson_ksamp([FWHM_BB_data[(impulse<0.1)&(mass<=0.42)], FWHM_BB_data[(impulse>=0.1)&(mass<=0.42)]])

print "FWHM IMPULSE low vs high:",np.round(actual_AD_test_val,2), np.round(actual_AD_p_val,6),"(A-D,p-val)"


actual_AD_test_val, out_array, actual_AD_p_val = stats.anderson_ksamp([tot_BB_data[(impulse<0.1)&(mass<=0.42)], tot_BB_data[(impulse>=0.1)&(mass<=0.42)]])

print "total IMPULSE low vs high:",np.round(actual_AD_test_val,2), np.round(actual_AD_p_val,6),"(A-D,p-val)\n"

actual_low = np.mean(FWHM_BB_data[np.argsort(impulse)[:22]])
actual_high = np.mean(FWHM_BB_data[np.argsort(impulse)[22:]])

actual_diff = actual_high - actual_low

late_FWHM_BB_data =copy.deepcopy(FWHM_BB_data[mass<=0.42])
late_impulse = copy.deepcopy(impulse[mass<=0.42])

actual_low_late = np.mean(late_FWHM_BB_data[np.argsort(late_impulse)[:14]])#14
actual_high_late = np.mean(late_FWHM_BB_data[np.argsort(late_impulse)[14:]])#14

print len(late_impulse)
#exit()
actual_diff_late = actual_high_late - actual_low_late
#exit()

#plt.hist(FWHM_BB_data[np.argsort(impulse)[:22]],alpha=0.5)
#plt.hist(FWHM_BB_data[np.argsort(impulse)[22:]],alpha=0.5)
#plt.show()

#kendall_tau, kendall_p_value = scipy.stats.kendalltau(FWHM_BB_data[np.argsort(impulse)[:22]],FWHM_BB_data[np.argsort(impulse)[22:]])
#print kendall_tau, kendall_p_value

mc_impulse = copy.deepcopy(impulse)
 
low_impulse_Teff = FWHM_BB_data[np.argsort(impulse)[:22]]
e_low_impulse_Teff = e_FWHM_BB_data[np.argsort(impulse)[:22]]
e_low_impulse_Teff[e_low_impulse_Teff<200.0] = 200.0

high_impulse_Teff = FWHM_BB_data[np.argsort(impulse)[22:]]
e_high_impulse_Teff = e_FWHM_BB_data[np.argsort(impulse)[22:]]
e_high_impulse_Teff[e_high_impulse_Teff<200.0] = 200.0

"""
n_trials = 100
for i in range(n_trials):
    
    mc_high_temps = np.random.normal(high_impulse_Teff, e_high_impulse_Teff)
    mc_low_temps = np.random.normal(low_impulse_Teff, e_low_impulse_Teff)

    drop_ind = int(np.random.random()*22)
"""

n_trials = 1000

separations=[]
late_separations=[]
for i in range(n_trials):
    mc_impulse = copy.deepcopy(impulse)
    mc_Teff = copy.deepcopy(FWHM_BB_data)
    mc_late_impulse = copy.deepcopy(late_impulse)
    mc_late_Teff = copy.deepcopy(late_FWHM_BB_data)

    np.random.shuffle(mc_Teff)
    np.random.shuffle(mc_late_Teff)

    mean_low = np.mean(mc_Teff[np.argsort(mc_impulse)[:22]])
    mean_high = np.mean(mc_Teff[np.argsort(mc_impulse)[22:]])
    mean_difference = mean_high-mean_low
    separations.append(mean_difference)

    mean_low_late = np.mean(mc_late_Teff[np.argsort(mc_late_impulse)[:14]])
    mean_high_late = np.mean(mc_late_Teff[np.argsort(mc_late_impulse)[14:]])
    mean_difference_late = mean_high_late - mean_low_late
    late_separations.append(mean_difference_late)
    
separations=np.array(separations)
late_separations = np.array(late_separations)

num_greater = len(separations[separations>=actual_diff]) #+ len(separations[separations<=(-actual_diff)])
num_greater_late = len(late_separations[late_separations>=actual_diff_late]) #+ len(late_separations[late_separations<=(-actual_diff_late)])

#print len(separations[separations>actual_diff])
#print len(separations[separations<(-actual_diff)])

perc_greater =  str(np.round(100.0*((1.0*num_greater)/(1.0*n_trials)),3))
"""
plt.title(perc_greater+" %")
plt.hist(separations,color="royalblue")
plt.axvline(actual_diff,color="darkorange")
plt.show()
"""
perc_greater_late =  str(np.round(100.0*((1.0*num_greater_late)/(1.0*n_trials)),3))

"""
plt.title(perc_greater_late+" %")
plt.hist(late_separations,color="firebrick")
plt.axvline(actual_diff_late,color="darkorange")
plt.show()
"""
print "% greater",perc_greater
print "% greater late",perc_greater_late
#exit()

#########################
###     BIG FIGURE    ###
#########################

#plt.hist(tot_BB_data,label="tot",alpha=0.33)
#plt.hist(FWHM_BB_data,label="FWHM",alpha=0.33)
#plt.legend()
#plt.show()

fig, ax = plt.subplots(figsize=(12,12))
plt.axis('off')

ax1 = fig.add_subplot(4,2,1)

popt, pcov = curve_fit(linear, Evry_Erg, np.log10(FWHM_BB_data))
log_x_arr = np.linspace(0.999*np.min(Evry_Erg), 1.001*np.max(Evry_Erg), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "energy",popt
#print 10.0**linear(33.0, *popt)
#print 10.0**linear(34.0, *popt)
#exit()
ax1.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax1.errorbar(10.0**Evry_Erg[mass<=0.42], FWHM_BB_data[mass<=0.42], xerr=(10.0**e_Evry_Erg[mass<=0.42]), yerr=1.25*e_FWHM_BB_data[mass<=0.42], marker="o", ms=5, ls="none", color="darkorange")
ax1.errorbar(10.0**Evry_Erg[mass>0.42], FWHM_BB_data[mass>0.42], xerr=(10.0**e_Evry_Erg[mass>0.42]), yerr=1.25*e_FWHM_BB_data[mass>0.42], marker="o", ms=5, ls="none", color="mediumpurple")

ax1.set_xscale("log")
ax1.set_yscale("log")
ax1.set_xlabel("Energy in $g^{\prime}$ [erg]", fontsize=14)
ax1.set_ylabel("Peak $T_\mathrm{Eff}$  [K]", fontsize=14)


y_formatter = FixedFormatter(['', '', '5,000', '', '', '', '', '20,000', '', '40,000', ''])
y_locator = FixedLocator([3000, 4000, 5000, 6000, 7000, 8000, 9000, 20000, 30000, 40000, 50000])
ax1.yaxis.set_minor_formatter(y_formatter)
ax1.yaxis.set_minor_locator(y_locator)

ax1.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax1.tick_params(labelsize=12)
for tick in ax1.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12) 

ax1.text(10.0**31.05,31000.0,"M$>$0.42M$_\odot$",color="mediumpurple",fontsize=13)
ax1.text(10.0**31.05,21000.0,"M$\leq$0.42M$_\odot$",color="darkorange",fontsize=13)
    
ax2 = fig.add_subplot(4,2,2)

popt, pcov = curve_fit(linear, np.log10(impulse), np.log10(FWHM_BB_data))
log_x_arr = np.linspace(0.999*np.min(np.log10(impulse)), 1.001*np.max(np.log10(impulse)), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "imoulse",popt

ax2.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax2.errorbar(impulse[mass<=0.42], FWHM_BB_data[mass<=0.42], xerr=e_impulse[mass<=0.42], yerr=1.25*e_FWHM_BB_data[mass<=0.42], marker="o", ms=5, ls="none", color="darkorange")
ax2.errorbar(impulse[mass>0.42], FWHM_BB_data[mass>0.42], xerr=e_impulse[mass>0.42], yerr=1.25*e_FWHM_BB_data[mass>0.42], marker="o", ms=5, ls="none", color="mediumpurple")

ax2.set_xscale("log")
ax2.set_yscale("log")
ax2.set_xlabel("Impulse [Ampl./FWHM]", fontsize=14)
ax2.set_ylabel("Peak $T_\mathrm{Eff}$  [K]", fontsize=14)

y_formatter = FixedFormatter(['', '', '5,000', '', '', '', '', '20,000', '', '40,000', ''])
y_locator = FixedLocator([3000, 4000, 5000, 6000, 7000, 8000, 9000, 20000, 30000, 40000, 50000])
ax2.yaxis.set_minor_formatter(y_formatter)
ax2.yaxis.set_minor_locator(y_locator)

ax2.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax2.tick_params(labelsize=12)
for tick in ax2.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12) 

ax3 = fig.add_subplot(4,2,3)

#tot_BB_data_trap, e_tot_BB_data_trap, E_tot_BB_data_trap

popt, pcov = curve_fit(linear, Evry_Erg, np.log10(tot_BB_data_trap))
log_x_arr = np.linspace(0.999*np.min(Evry_Erg), 1.001*np.max(Evry_Erg), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "total energy",popt

ax3.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax3.errorbar(10.0**Evry_Erg[mass<=0.42], tot_BB_data_trap[mass<=0.42], xerr=(10.0**e_Evry_Erg[mass<=0.42]), yerr=[e_tot_BB_data_trap[mass<=0.42],E_tot_BB_data_trap[mass<=0.42]], marker="o", ms=5, ls="none", color="darkorange")

ax3.errorbar(10.0**Evry_Erg[mass>0.42], tot_BB_data_trap[mass>0.42], xerr=(10.0**e_Evry_Erg[mass>0.42]), yerr=[e_tot_BB_data_trap[mass>0.42],E_tot_BB_data_trap[mass>0.42]], marker="o", ms=5, ls="none", color="mediumpurple")

ax3.set_xscale("log")
ax3.set_yscale("log")
ax3.set_xlabel("Energy in $g^{\prime}$ [erg]", fontsize=14)
ax3.set_ylabel("Entire flare $T_\mathrm{Eff}$  [K]", fontsize=14)

y_formatter = FixedFormatter(['', '', '5,000', '', '', '', '', '20,000', '', '40,000', ''])
y_locator = FixedLocator([3000, 4000, 5000, 6000, 7000, 8000, 9000, 20000, 30000, 40000, 50000])
ax3.yaxis.set_minor_formatter(y_formatter)
ax3.yaxis.set_minor_locator(y_locator)

ax3.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax3.tick_params(labelsize=12)
for tick in ax3.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12)

ax4 = fig.add_subplot(4,2,4)

popt, pcov = curve_fit(linear, np.log10(impulse), np.log10(tot_BB_data_trap))
log_x_arr = np.linspace(0.999*np.min(np.log10(impulse)), 1.001*np.max(np.log10(impulse)), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "total impulse",popt

ax4.plot(10.0**log_x_arr, fit_log_line, color="grey")

#tot_BB_data_trap, e_tot_BB_data_trap, E_tot_BB_data_trap

ax4.errorbar(impulse[mass<=0.42], tot_BB_data_trap[mass<=0.42], xerr=e_impulse[mass<=0.42], yerr=1.25*e_tot_BB_data[mass<=0.42], marker="o", ms=5, ls="none", color="darkorange")
ax4.errorbar(impulse[mass>0.42], tot_BB_data_trap[mass>0.42], xerr=e_impulse[mass>0.42], yerr=[e_tot_BB_data_trap[mass>0.42],E_tot_BB_data_trap[mass>0.42]], marker="o", ms=5, ls="none", color="mediumpurple")

ax4.set_xscale("log")
ax4.set_yscale("log")
ax4.set_xlabel("Impulse [Ampl./FWHM]", fontsize=14)
ax4.set_ylabel("Entire flare $T_\mathrm{Eff}$  [K]", fontsize=14)

y_formatter = FixedFormatter(['', '', '5,000', '', '', '', '', '20,000', '', '40,000', ''])
y_locator = FixedLocator([3000, 4000, 5000, 6000, 7000, 8000, 9000, 20000, 30000, 40000, 50000])
ax4.yaxis.set_minor_formatter(y_formatter)
ax4.yaxis.set_minor_locator(y_locator)

ax4.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax4.tick_params(labelsize=12)
for tick in ax4.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12)

ax5 = fig.add_subplot(4,2,5)

popt, pcov = curve_fit(linear, Evry_Erg[T_abv_14K>0.0], np.log10(T_abv_14K[T_abv_14K>0.0]))
log_x_arr = np.linspace(0.995*np.min(Evry_Erg[T_abv_14K>0.0]), 1.001*np.max(Evry_Erg[T_abv_14K>0.0]), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "energy vs t_dur abv. 14K",popt

ax5.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax5.errorbar(10.0**Evry_Erg[(mass<=0.42)&(T_abv_14K>0.0)], T_abv_14K[(mass<=0.42)&(T_abv_14K>0.0)], xerr=(10.0**e_Evry_Erg[(mass<=0.42)&(T_abv_14K>0.0)]), yerr=1.0, marker="o", ms=5, ls="none", color="darkorange")
ax5.errorbar(10.0**Evry_Erg[(mass>0.42)&(T_abv_14K>0.0)], T_abv_14K[(mass>0.42)&(T_abv_14K>0.0)], xerr=(10.0**e_Evry_Erg[(mass>0.42)&(T_abv_14K>0.0)]), yerr=1.0, marker="o", ms=5, ls="none", color="mediumpurple")

ax5.set_xscale("log")
ax5.set_yscale("log")
ax5.set_xlabel("Energy in $g^{\prime}$ [erg]", fontsize=14)
ax5.set_ylabel("Amount of time above\n$T_\mathrm{Eff}>$14,000 K [min]", fontsize=14)

y_formatter = FixedFormatter(["", "2", "", "", "5", "", "", "", "", "20"])
y_locator = FixedLocator([1, 2, 3, 4, 5, 6, 7, 8, 9, 20])
ax5.yaxis.set_minor_formatter(y_formatter)
ax5.yaxis.set_minor_locator(y_locator)

ax5.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax5.tick_params(labelsize=12)
for tick in ax5.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12)

ax6 = fig.add_subplot(4,2,6)

ax6.errorbar(impulse[(mass<=0.42)&(T_abv_14K>0.0)], T_abv_14K[(mass<=0.42)&(T_abv_14K>0.0)], xerr=e_impulse[(mass<=0.42)&(T_abv_14K>0.0)], yerr=1.0, marker="o", ms=5, ls="none", color="darkorange")
ax6.errorbar(impulse[(mass>0.42)&(T_abv_14K>0.0)], T_abv_14K[(mass>0.42)&(T_abv_14K>0.0)], xerr=e_impulse[(mass>0.42)&(T_abv_14K>0.0)], yerr=1.0, marker="o", ms=5, ls="none", color="mediumpurple")

ax6.set_xscale("log")
ax6.set_yscale("log")

ax6.set_xlabel("Impulse [Ampl./FWHM]", fontsize=14)
ax6.set_ylabel("Amount of time above\n$T_\mathrm{Eff}>$14,000 K [min]", fontsize=14)

y_formatter = FixedFormatter(["", "2", "", "", "5", "", "", "", "", "20"])
y_locator = FixedLocator([1, 2, 3, 4, 5, 6, 7, 8, 9, 20])
ax6.yaxis.set_minor_formatter(y_formatter)
ax6.yaxis.set_minor_locator(y_locator)

ax6.get_yaxis().set_major_formatter(
    matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

ax6.tick_params(labelsize=12)
for tick in ax6.yaxis.get_minor_ticks():
    tick.label.set_fontsize(12)

ax7 = fig.add_subplot(4,2,7)

ax7.errorbar(10.0**Evry_Erg[mass<=0.42], color[mass<=0.42], xerr=(10.0**e_Evry_Erg[mass<=0.42]), yerr=e_color[mass<=0.42], marker="o", ms=5, ls="none", color="darkorange")
ax7.errorbar(10.0**Evry_Erg[mass>0.42], color[mass>0.42], xerr=(10.0**e_Evry_Erg[mass>0.42]), yerr=e_color[mass>0.42], marker="o", ms=5, ls="none", color="mediumpurple")

ax7.set_xlabel("Energy in $g^{\prime}$ [erg]", fontsize=14)
ax7.set_ylabel("Peak color [$F_{g^{\prime}}$-$F_\mathrm{TESS}$]", fontsize=14)

ax7.set_xscale("log")
ax7.set_yscale("log")

ax7.tick_params(labelsize=12)

ax8 = fig.add_subplot(4,2,8)

popt, pcov = curve_fit(linear, np.log10(impulse), np.log10(color))
log_x_arr = np.linspace(0.95*np.min(np.log10(impulse)), 1.05*np.max(np.log10(impulse)), num=100)
fit_log_line = 10.0**linear(log_x_arr, *popt)
print "impulse vs color",popt
ax8.plot(10.0**log_x_arr, fit_log_line, color="grey")

ax8.errorbar(impulse[mass<=0.42], color[mass<=0.42], xerr=e_impulse[mass<=0.42], yerr=e_color[mass<=0.42], marker="o", ms=5, ls="none", color="darkorange")
ax8.errorbar(impulse[mass>0.42], color[mass>0.42], xerr=e_impulse[mass>0.42], yerr=e_color[mass>0.42], marker="o", ms=5, ls="none", color="mediumpurple")

ax8.set_xlabel("Impulse [Ampl./FWHM]", fontsize=14)
ax8.set_ylabel("Peak color [$F_{g^{\prime}}$-$F_\mathrm{TESS}$]", fontsize=14)

ax8.set_xscale("log")
ax8.set_yscale("log")

ax8.tick_params(labelsize=12)

plt.tight_layout()
plt.savefig("relations_teff_vars.png")
plt.show()

exit()

plt.hist(T_abv_14K[T_abv_14K>0.0])
plt.show()
exit()

print np.median(T_abv_14K[T_abv_14K>0.0]),np.std(T_abv_14K[T_abv_14K>0.0]),"min above 14,000 K",len(T_abv_14K[T_abv_14K>0.0])/44.0
print np.median(T_abv_20K[T_abv_20K>0.0]),np.std(T_abv_20K[T_abv_20K>0.0]),"min above 20,000 K",len(T_abv_20K[T_abv_20K>0.0])/44.0
print np.median(T_abv_30K[T_abv_30K>0.0]),np.std(T_abv_30K[T_abv_30K>0.0]),"min above 30,000 K",len(T_abv_30K[T_abv_30K>0.0])/44.0
exit()

# T_abv_30K, T_abv_20K, T_abv_14K, 10.0**Evry_Erg
plt.loglog(10.0**Evry_Erg[T_abv_14K>0.0], T_abv_14K[T_abv_14K>0.0], marker="o",ls="none",color="mediumpurple")
#plt.loglog(Ro[T_abv_20K>0.0], T_abv_20K[T_abv_20K>0.0], marker="o",ls="none",color="darkorange")
#plt.loglog(Ro[T_abv_30K>0.0], T_abv_30K[T_abv_30K>0.0], marker="o",ls="none",color="purple")
plt.show()
exit()

plt.loglog(impulse[mass<=0.42], FWHM_BB_data[mass<=0.42], marker="o",ls="none",color="darkorange")
plt.loglog(impulse[mass>0.42], FWHM_BB_data[mass>0.42], marker="o",ls="none",color="mediumpurple")
#plt.loglog(color, FWHM_BB_data, marker="o",ls="none")
#plt.loglog(color, inst_temp, marker="o",ls="none")
plt.show()
#exit()

#energy_normed = 10.0**Evry_Erg
#energy_normed -= np.min(energy_normed)
#energy_normed /= np.max(energy_normed)

#print Ro
#exit()

#plt.loglog(Prot[Prot>0.0], tot_BB_sampl[Prot>0.0], marker="o", ls="none", color="darkorange")
#plt.show()
#exit()

#plot_var1_vs_var2(impulse, FWHM_BB_data)
#exit()

#plt.hist(FWHM_BB_data)
#plt.show()
#exit()

"""
plt.loglog(evr_peakFF[mass<0.4], FWHM_BB_data[mass<0.4], marker="o", ls="none", color="darkorange")
plt.loglog(evr_peakFF[(mass>=0.4)&(mass<0.55)], FWHM_BB_data[(mass>=0.4)&(mass<0.55)], marker="o", ls="none", color="mediumpurple")
plt.loglog(evr_peakFF[mass>=0.55], FWHM_BB_data[mass>=0.55], marker="o", ls="none", color="purple")

plt.xlabel("Ampl [FF in g]",fontsize=14)
plt.ylabel("$T_\mathrm{Eff}$  in flare FWHM [K]",fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.tight_layout()
plt.show()
exit()
"""

plt.loglog(10.0**Evry_Erg[mass<0.4], FWHM_BB_data[mass<0.4], marker="o", ls="none", color="darkorange")
plt.loglog(10.0**Evry_Erg[(mass>=0.4)&(mass<0.55)], FWHM_BB_data[(mass>=0.4)&(mass<0.55)], marker="o", ls="none", color="mediumpurple")
plt.loglog(10.0**Evry_Erg[mass>=0.55], FWHM_BB_data[mass>=0.55], marker="o", ls="none", color="purple")

plt.xlabel("Energy [erg]",fontsize=14)
plt.ylabel("$T_\mathrm{Eff}$  in flare FWHM [K]",fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.tight_layout()
plt.show()
#exit()

binary_TIC = np.array([294750180,5796048,206327797,220433364,392756613,142086812,441398770,192543856])

bin_impulse=[]
bin_temps=[]
for BTID in binary_TIC:
    bin_impulse.append(impulse[TIC_ID==BTID][0])
    bin_temps.append(FWHM_BB_data[TIC_ID==BTID][0])
bin_impulse=np.array(bin_impulse)
bin_temps=np.array(bin_temps)

MCT = 0.42 #0.42

plt.loglog(impulse[mass<MCT], inst_temp[mass<MCT], marker="o", ls="none", color="darkorange")
plt.loglog(impulse[mass>=MCT], inst_temp[mass>=MCT], marker="o", ls="none", color="darkviolet")
#plt.loglog(bin_impulse, bin_temps, marker="o", ls="none", color="red")

plt.xlabel("Impulse [Ampl./FWHM]",fontsize=14)
plt.ylabel("$T_\mathrm{Eff}$  in flare FWHM [K]",fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.tight_layout()
plt.show()

exit()

plt.loglog(10.0**Evry_Erg, FWHM_BB_data, marker="o", ls="none", color="black")
plt.xlabel("Flare Energy [erg]",fontsize=14)
plt.ylabel("$T_\mathrm{Eff}$  in flare FWHM [K]",fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.tight_layout()
plt.show()
exit()

plt.loglog(impulse[(Evry_Erg_bol>33.0)&(Evry_Erg_bol<34.0)], FWHM_BB_data[(Evry_Erg_bol>33.0)&(Evry_Erg_bol<34.0)], marker="o", ls="none", color="black")
plt.show()
exit()

#print n_peaks

#plt.loglog(impulse, (FWHM_BB_data/n_peaks), marker="o", ls="none", color="red")
fig = plt.figure()
ax = plt.gca()

#im = ax.scatter(10.0**Evry_Erg, FWHM_BB_data, c=color)
#im = ax.scatter(impulse[mass>0.5], FWHM_BB_data[mass>0.5], c=color[mass>0.5])
plt.loglog(impulse[mass>0.4], tot_BB_sampl[mass>0.4], marker="o", ls="none", color="purple")
plt.loglog(impulse[mass<0.4], tot_BB_sampl[mass<0.4], marker="o", ls="none", color="red")
#ax.set_yscale('log')
#ax.set_xscale('log')
#fig.colorbar(im, ax=ax)

plt.show()
exit()
#print Evry_Erg_bol


m_dwarf = np.array([x for x in np.arange(len(SpT)) if "M" in SpT[x]])
k_dwarf = np.array([x for x in np.arange(len(SpT)) if "K" in SpT[x]])

print k_dwarf

m_dwarf_flares = Evry_Erg_bol[m_dwarf]
print len(m_dwarf_flares[m_dwarf_flares>=33.0])
exit()
print np.sort(Evry_Erg_bol)
exit()
print len(Evry_Erg[(mass<=0.59) & (Evry_Erg_bol>=33.0)])
exit()

print np.min(mass),np.max(mass),"m_sol"
print np.median(g_mags),np.std(g_mags),np.min(g_mags),np.max(g_mags),"gmag"
print np.median(distance),np.std(distance),np.min(distance),np.max(distance),"distances"
med_g, bot_g, top_g = compute_1sigma_CI(g_mags)
med_dist, bot_dist, top_dist = compute_1sigma_CI(distance)
print med_g, bot_g, top_g
print med_dist, bot_dist, top_dist
exit()
print len(np.unique(TIC_ID))
