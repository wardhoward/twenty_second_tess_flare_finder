import numpy as np

index=[]
tic=[]
date=[]
time=[]
with open("sorted_datetimes_v1.csv","r") as INFILE:
    for lines in INFILE:
        index.append(int(lines.split(",")[0]))
        tic.append(int(lines.split(",")[1]))
        date.append(int(lines.split(",")[2]))
        time.append(str(lines.split(",")[3].rstrip("\n")))
index=np.array(index)
tic=np.array(tic)
date=np.array(date)
time=np.array(time)

srt_ind = np.argsort(date)

index=index[srt_ind]
tic=tic[srt_ind]
date=date[srt_ind]
time=time[srt_ind]

for h in range(len(index)):
    info = str(index[h])+","+str(tic[h])+","+str(date[h])+","+str(time[h])+"\n"
    with open("sorted_datetimes_v2.csv","a") as OUTFILE:
        OUTFILE.write(info)
